import { world, system } from "@minecraft/server";
export function entityPOINT(event){
    if(world.getDynamicProperty('killPointSystem') !== undefined){
    if(world.getDynamicProperty('killPointSystem') !== false){
    const kill_id = ['killcount_zombie','killcount_skeleton','killcount_spider','killcount_creeper','killcount_enderman','killcount_warden','killcount_phantom']
    const kill_id_2 = ['killpoint_zombie','killpoint_skeleton','killpoint_spider','killpoint_creeper','killpoint_enderman','killpoint_warden','killpoint_phantom']
    const entity = event.hurtEntity; // ダメージを受けたエンティティ
    // ヘルス情報を取得
    const healthComponent = entity.getComponent("health");
    if (healthComponent) {
        const currentHealth = healthComponent.currentValue;
        if (currentHealth <= 0) {
        // ダメージ後の体力が0以下なら死亡と判定
            // 死亡したエンティティの種類を確認
            if ((entity.typeId === "minecraft:zombie")) {
                // プレイヤーが倒した場合の確認
                const damager = event.damageSource.damagingEntity;
                if (damager?.typeId === "minecraft:player") {
                    const player = damager;
                    var zombiecount = player.getDynamicProperty('zombiecount')
                    if(zombiecount==undefined){
                        zombiecount=0
                    }
                    player.setDynamicProperty('zombiecount',zombiecount+1)
                    zombiecount = player.getDynamicProperty('zombiecount')
                    if(zombiecount==world.getDynamicProperty(`${kill_id[0]}`)){
                        player.runCommand(`scoreboard players add @s money ${world.getDynamicProperty(kill_id_2[0])}`)
                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(POINT)§r] §e${world.getDynamicProperty(kill_id_2[0])}POINTゲットしました§6(ゾンビ)"}]}`)
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.9 0.7`)
                        player.setDynamicProperty('zombiecount',0)
                        return;
                    } 
                    // プレイヤーにメッセージを送る
                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(POINT)§r] §aPOINTゲットまで残り§b${world.getDynamicProperty(kill_id[0])-zombiecount}§a体です"}]}`)
                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.3 0.7`)
                }
            }
            if (entity.typeId === "minecraft:phantom") {
                // プレイヤーが倒した場合の確認
                const damager = event.damageSource.damagingEntity;
                if (damager?.typeId === "minecraft:player") {
                    const player = damager;
                    var phantomcount = player.getDynamicProperty('phantomcount')
                    if(phantomcount==undefined){
                        phantomcount=0
                    }
                    player.setDynamicProperty('phantomcount',phantomcount+1)
                    phantomcount = player.getDynamicProperty('phantomcount')
                    if(phantomcount==world.getDynamicProperty(`${kill_id[6]}`)){
                        player.runCommand(`scoreboard players add @s money ${world.getDynamicProperty(kill_id_2[6])}`)
                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(POINT)§r] §e${world.getDynamicProperty(kill_id_2[6])}POINTゲットしました§6(ファントム)"}]}`)
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.9 0.7`)
                        player.setDynamicProperty('phantomcount',0)
                        return;
                    } 
                    // プレイヤーにメッセージを送る
                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(POINT)§r] §aPOINTゲットまで残り§b${world.getDynamicProperty(kill_id[6])-skeletoncount}§a体です"}]}`)
                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.3 0.7`)
                }
            }
            if (entity.typeId === "minecraft:skeleton") {
                // プレイヤーが倒した場合の確認
                const damager = event.damageSource.damagingEntity;
                if (damager?.typeId === "minecraft:player") {
                    const player = damager;
                    var skeletoncount = player.getDynamicProperty('skeletoncount')
                    if(skeletoncount==undefined){
                        skeletoncount=0
                    }
                    player.setDynamicProperty('skeletoncount',skeletoncount+1)
                    skeletoncount = player.getDynamicProperty('skeletoncount')
                    if(skeletoncount==world.getDynamicProperty(`${kill_id[1]}`)){
                        player.runCommand(`scoreboard players add @s money ${world.getDynamicProperty(kill_id_2[1])}`)
                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(POINT)§r] §e${world.getDynamicProperty(kill_id_2[1])}POINTゲットしました§6(スケルトン)"}]}`)
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.9 0.7`)
                        player.setDynamicProperty('skeletoncount',0)
                        return;
                    } 
                    // プレイヤーにメッセージを送る
                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(POINT)§r] §aPOINTゲットまで残り§b${world.getDynamicProperty(kill_id[1])-skeletoncount}§a体です"}]}`)
                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.3 0.7`)
                }
            }
            if (entity.typeId === "minecraft:warden") {
                // プレイヤーが倒した場合の確認
                const damager = event.damageSource.damagingEntity;
                if (damager?.typeId === "minecraft:player") {
                    const player = damager;
                    var wardencount = player.getDynamicProperty('wardencount')
                    if(wardencount==undefined){
                        wardencount=0
                    }
                    player.setDynamicProperty('wardencount',wardencount+1)
                    wardencount = player.getDynamicProperty('wardencount')
                    if(wardencount==world.getDynamicProperty(`${kill_id[5]}`)){
                        player.runCommand(`scoreboard players add @s money ${world.getDynamicProperty(kill_id_2[5])}`)
                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(POINT)§r] §e${world.getDynamicProperty(kill_id_2[5])}POINTゲットしました§6(ウォーデン)"}]}`)
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.9 0.7`)
                        player.setDynamicProperty('wardencount',0)
                        return;
                    } 
                    // プレイヤーにメッセージを送る
                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(POINT)§r] §aPOINTゲットまで残り§b${world.getDynamicProperty(kill_id[5])-wardencount}§a体です"}]}`)
                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.3 0.7`)
                }
            }
            if (entity.typeId === "minecraft:creeper") {
                // プレイヤーが倒した場合の確認
                const damager = event.damageSource.damagingEntity;
                if (damager?.typeId === "minecraft:player") {
                    const player = damager;
                    var creepercount = player.getDynamicProperty('creepercount')
                    if(creepercount==undefined){
                        creepercount=0
                    }
                    player.setDynamicProperty('creepercount',creepercount+1)
                    creepercount = player.getDynamicProperty('creepercount')
                    if(creepercount==world.getDynamicProperty(`${kill_id[3]}`)){
                        player.runCommand(`scoreboard players add @s money ${world.getDynamicProperty(kill_id_2[3])}`)
                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(POINT)§r] §e${world.getDynamicProperty(kill_id_2[3])}POINTゲットしました§6(クリーパー)"}]}`)
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.9 0.7`)
                        player.setDynamicProperty('creepercount',0)
                        return;
                    } 
                    // プレイヤーにメッセージを送る
                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(POINT)§r] §aPOINTゲットまで残り§b${world.getDynamicProperty(kill_id[3])-creepercount}§a体です"}]}`)
                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.3 0.7`)
                }
            }
            if (entity.typeId === "minecraft:spider") {
                // プレイヤーが倒した場合の確認
                const damager = event.damageSource.damagingEntity;
                if (damager?.typeId === "minecraft:player") {
                    const player = damager;
                    var spidercount = player.getDynamicProperty('spidercount')
                    if(spidercount==undefined){
                        spidercount=0
                    }
                    player.setDynamicProperty('spidercount',spidercount+1)
                    spidercount = player.getDynamicProperty('spidercount')
                    if(spidercount==world.getDynamicProperty(`${kill_id[2]}`)){
                        player.runCommand(`scoreboard players add @s money ${world.getDynamicProperty(kill_id_2[2])}`)
                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(POINT)§r] §e${world.getDynamicProperty(kill_id_2[2])}POINTゲットしました§6(蜘蛛)"}]}`)
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.9 0.7`)
                        player.setDynamicProperty('spidercount',0)
                        return;
                    } 
                    // プレイヤーにメッセージを送る
                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(POINT)§r] §aPOINTゲットまで残り§b${world.getDynamicProperty(kill_id[2])-spidercount}§a体です"}]}`)
                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.3 0.7`)
                }
            }
            if (entity.typeId === "minecraft:enderman") {
                // プレイヤーが倒した場合の確認
                const damager = event.damageSource.damagingEntity;
                if (damager?.typeId === "minecraft:player") {
                    const player = damager;
                    var endermancount = player.getDynamicProperty('endermancount')
                    if(endermancount==undefined){
                        endermancount=0
                    }
                    player.setDynamicProperty('endermancount',endermancount+1)
                    endermancount = player.getDynamicProperty('endermancount')
                    if(endermancount==world.getDynamicProperty(`${kill_id[4]}`)){
                        player.runCommand(`scoreboard players add @s money ${world.getDynamicProperty(kill_id_2[4])}`)
                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(POINT)§r] §e${world.getDynamicProperty(kill_id_2[4])}POINTゲットしました§6(エンダーマン)"}]}`)
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.9 0.7`)
                        player.setDynamicProperty('endermancount',0)
                        return;
                    } 
                    // プレイヤーにメッセージを送る
                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(POINT)§r] §aPOINTゲットまで残り§b${world.getDynamicProperty(kill_id[2])-endermancount}§a体です"}]}`)
                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.3 0.7`)
                }
            }
        }
    }
  } 
 }
}
