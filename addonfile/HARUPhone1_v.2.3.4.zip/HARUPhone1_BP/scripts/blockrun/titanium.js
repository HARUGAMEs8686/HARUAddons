import { world,system } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";

var player_Cash_Data = {}

export function Titanium(eventData){
    const player = eventData.player
        player_Cash_Data[player.id]={}
        system.run(() => {
            if (!player_Cash_Data[player.id].TitaniumStop) {
                player_Cash_Data[player.id].TitaniumStop = true
                //ここから実行

                //時刻を取得
                const now = new Date();
                const japanTime = new Date(now.getTime() + 9 * 60 * 60 * 1000);
                const hours = String(japanTime.getUTCHours()).padStart(2, "0");
                const minutes = String(japanTime.getUTCMinutes()).padStart(2, "0");
                var time = `${hours}:${minutes}`

                var form = new ActionFormData();
                form.title("Titanium");
                form.body(`§l§b${time}\n\n§r§s\n§6>>>§5会社を作成§r/§9選択§rしてください`);
                form.button("§5会社を作成");
                form.button("§1会社への招待を確認");
                form.show(player).then(r => {
                    if (r.canceled) return;
                    let response = r.selection;
                    switch (response) {
                        case 0:
                        break;
                        case 1:
                        break;
                    }
                })
                //ここまで
                system.runTimeout(() => {
                    player_Cash_Data[player.id].TitaniumStop = false
                }, 20); 
        }
    })    
}