import { world, system } from "@minecraft/server";
import { ActionFormData,MessageFormData,ModalFormData } from "@minecraft/server-ui";
import { config } from "../../../config"

export function LiteFrame_SystemA(eventData){
    const player = eventData.source;
    
    var form = new ModalFormData();
    form.title(`${config['main'][0]}`);
    for (let i = 0; i < player_Cash_Data[player.id].CommandRunNumber; i++){
       form.textField(`実行:§b${i}`, "")
    }
    form.show(player).then(r => {
        if (r.canceled) {
            return;
        };
        player_Cash_Data[player.id].CommandRunList = []
        player_Cash_Data[player.id].CommandRunList_text = ''
        for (let i = 0; i < player_Cash_Data[player.id].CommandRunNumber; i++){
            player_Cash_Data[player.id].CommandRunList.push(r.formValues[i])
            player_Cash_Data[player.id].CommandRunList_text = player_Cash_Data[player.id].CommandRunList_text+`${r.formValues[i]}\n`
        }
        var form = new ActionFormData();
        form.title(`${config['main'][0]}`);
        form.body(`§l§b${time}\n§r§aApp内容\n§sコマンド§r(上から実行されます)\n§a${player_Cash_Data[player.id].CommandRunList_text}`);
        form.button(`§5保存`);
        form.button(`§1キャンセル`);
        form.show(player).then(r => {
            if (r.canceled) return;
            let response = r.selection;
            switch (response) {
                case 0:
                //Code生成
                  let number = '';
                  for (let i = 0; i < 8; i++) {
                     number += Math.floor(Math.random() * 10); // 0〜9のランダムな数字
                  }
                    world.setDynamicProperty(`LiteFrame_${player_Cash_Data[player.id].ApplicationName}_${number}`,JSON.stringify(player_Cash_Data[player.id]))
                    
                  //AppDataにアプリIDを保存
                    var AppData = world.getDynamicProperty(`AppData`)
                    if(AppData==undefined){
                        var AppData=[]
                    }else{
                     var AppData = JSON.parse(AppData);
                    }
                    AppData.push([`LiteFrame_${player_Cash_Data[player.id].ApplicationName}_${number}`,'LiteFrameA'])
                    world.setDynamicProperty(`AppData`,JSON.stringify(AppData))
    
                    player.sendMessage(`§r[§bHARU-XEditor§r] §a新規作成作成しました`)
                    player.playSound("random.toast", {
                        pitch: 1.5, 
                        volume: 1.0
                    }); 
                break;
                case 1:
                    player.sendMessage(`§r[§bHARU-XEditor§r] §a変更をキャンセルしました`)
                    player.playSound("random.toast", {
                        pitch: 1.4, 
                        volume: 1.0
                    });  
                break;
            }
        })
    })
}
