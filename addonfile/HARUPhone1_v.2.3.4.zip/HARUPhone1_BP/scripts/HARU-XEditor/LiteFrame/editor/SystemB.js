import { world, system } from "@minecraft/server";
import { ActionFormData,MessageFormData,ModalFormData } from "@minecraft/server-ui";
import { config } from "../../../config"

var player_Cash_Data = {}

export function LiteFrame_SystemB(eventData,Application){
    const player = eventData.source;
    //時刻を取得
    const now = new Date();
    const japanTime = new Date(now.getTime() + 9 * 60 * 60 * 1000);
    const hours = String(japanTime.getUTCHours()).padStart(2, "0");
    const minutes = String(japanTime.getUTCMinutes()).padStart(2, "0");
    var time = `${hours}:${minutes}`

    player_Cash_Data[player.id] = {}
    player_Cash_Data[player.id].Application = JSON.parse(world.getDynamicProperty(Application[0]))

    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body(`§l§b${time}`);
    form.button(`§5コマンド編集`);
    form.button(`§1コマンド実行数の編集`);
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                if(player_Cash_Data[player.id].Application.CommandRunList == undefined){
                    player_Cash_Data[player.id].Application.CommandRunList = []
                }
                //コマンド編集
                var form = new ModalFormData();
                form.title(`${config['main'][0]}`);
                for (let i = 0; i < player_Cash_Data[player.id].Application.CommandRunNumber; i++){
                  if(player_Cash_Data[player.id].Application.CommandRunList[i] == undefined){
                    form.textField(`実行:§b${i}`, `未設定`)
                  }else{
                    form.textField(`実行:§b${i}`, `${player_Cash_Data[player.id].Application.CommandRunList[i]}`)
                  }
                }
                form.show(player).then(r => {
                    if (r.canceled) {
                        return;
                    };
                    const COMMANDLIST = player_Cash_Data[player.id].Application.CommandRunList
                    player_Cash_Data[player.id].Application.CommandRunList = []
                    player_Cash_Data[player.id].CommandRunList_text = ''
                    for (let i = 0; i < player_Cash_Data[player.id].Application.CommandRunNumber; i++){
                      if(r.formValues[i] == ''){
                        player_Cash_Data[player.id].Application.CommandRunList.push(COMMANDLIST[i])
                      }else{
                        player_Cash_Data[player.id].Application.CommandRunList.push(r.formValues[i])
                      }
                        player_Cash_Data[player.id].CommandRunList_text = player_Cash_Data[player.id].CommandRunList_text+`${r.formValues[i]}\n`
                    }
                    var form = new ActionFormData();
                    form.title(`${config['main'][0]}`);
                    form.body(`§l§b${time}\n§r§a保存内容\n§sコマンド§r(上から実行されます)\n§a${player_Cash_Data[player.id].CommandRunList_text}`);
                    form.button(`§5保存`);
                    form.button(`§1キャンセル`);
                    form.show(player).then(r => {
                        if (r.canceled) return;
                        let response = r.selection;
                        switch (response) {
                            case 0:
                                world.setDynamicProperty(Application[0],JSON.stringify(player_Cash_Data[player.id].Application))
                                player.sendMessage(`§r[§bHARU-XEditor§r] §a保存しました`)
                                player.playSound("random.toast", {
                                    pitch: 1.5, 
                                    volume: 1.0
                                }); 
                            break;
                            case 1:
                                player.sendMessage(`§r[§bHARU-XEditor§r] §a保存をキャンセルしました`)
                                player.playSound("random.toast", {
                                    pitch: 1.4, 
                                    volume: 1.0
                                });  
                            break;
                        }
                    })
                })
            break;
            case 1:
                var form = new ModalFormData();
                form.title(`${config['main'][0]}`);
                form.textField(`コマンド実行数\n§5>>>§a現在§r:§b${player_Cash_Data[player.id].Application.CommandRunNumber}`, `半角数字`)
                form.show(player).then(r => {
                    if (r.canceled) {
                        return;
                    };
                    player_Cash_Data[player.id].Application.CommandRunNumber = Number(r.formValues[0])
                    world.setDynamicProperty(Application[0],JSON.stringify(player_Cash_Data[player.id].Application))
                    player.sendMessage(`§r[§bHARU-XEditor§r] §a変更を保存しました`)
                    player.playSound("random.toast", {
                        pitch: 1.4, 
                        volume: 1.0
                    }); 
                    LiteFrame_SystemA(eventData,Application)
                })
            break;
        }
    })
}
