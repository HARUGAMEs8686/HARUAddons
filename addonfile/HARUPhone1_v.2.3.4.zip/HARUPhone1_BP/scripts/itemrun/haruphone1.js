import { world, system } from "@minecraft/server";
import { ActionFormData,MessageFormData,ModalFormData } from "@minecraft/server-ui";

import { config } from "../config"
import { selection_HARUPAYSend, cashdataC } from "../main"

import { chatLoop2 } from '../HaruAssistant/Insight-2/assistantMain';
import { chatLoop3 } from '../HaruAssistant/Insight-3/assistantMain';

import { App } from '../App/AppMenu';

var selection_HARUPAYSend_import = selection_HARUPAYSend;

//一時データ
var player_Cash_Data = {}
//請求データ
var Claim = {}
//Quickデータ 
var shop_menu = [[],[]]
//仕事募集データ 
var quest = [[],[]]

//Quick関連
// 初期化時に保存済みデータを読み込む
function loadShopMenu() {
    const savedData = world.getDynamicProperty("shop_menu");
    if (savedData) {
        return JSON.parse(savedData);
    }
    return [[], []]; // デフォルト値（初回起動時用）
}

// データを保存する関数
function saveShopMenu(shopMenu) {
    world.setDynamicProperty("shop_menu", JSON.stringify(shopMenu));
}
//logデータ
var logs = {}
 logs['harupay'] = []
 logs['quick'] = []
 logs['quest'] = []

function cashdataB(){
    selection_HARUPAYSend_import=0
}
export function HARUPhone1(eventData){
    system.run(() => {
        //実行アイテム=additem:haruphone1
        if (eventData.itemStack.typeId === "additem:haruphone1"){
            const player = eventData.source;
            if(player.hasTag('op')&&world.getDynamicProperty('op_fast')===undefined){
                var form = new ModalFormData();
                form.textField("初期配布金額「後から変えられません」(半角数字)", "0")
                form.show(player).then(r => {
                    if (r.canceled) {
                        return;
                    };
                    if (r.formValues[0]>100000000){
                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§4設定した金額は上限をオーバーしています.1億以下で設定してください"}]}`)
                        selection_HARUPAYSend_import = 0;
                        return;
                    }
                    if(r.formValues[0]!==''){
                        world.setDynamicProperty('start_money',r.formValues[0])
                        world.setDynamicProperty('op_fast',1)
                        world.setDynamicProperty('money_start_system1', 1);
                        return;
                    }else{
                        player.runCommand('tellraw @s {"rawtext":[{"text":"§e初期設定を完了して下さい"}]}')
                        return;
                    }
                })
            }else{
                //money取得
                const score = world.scoreboard.getObjective("money").getScore(player.scoreboardIdentity);

                //時刻を取得
                const now = new Date();
                const japanTime = new Date(now.getTime() + 9 * 60 * 60 * 1000);
                const hours = String(japanTime.getUTCHours()).padStart(2, "0");
                const minutes = String(japanTime.getUTCMinutes()).padStart(2, "0");
                var time = `${hours}:${minutes}`

                //広告取得 (修正必須)
                var performance = world.getDynamicProperty('performance')
                if(performance==undefined){
                    var performance_system2=[]
                }else{
                var performance_system2 = JSON.parse(performance);
                }
                const random_performance = Math.floor(Math.random() * performance_system2.length)

                //playerの一時ファイルを作成(リセット)
                player_Cash_Data[player.id] = {}

            //HOME画面
            var form = new ActionFormData();
            form.title(`${config['main'][0]}`);
            form.body(`§l§b${time}`);
            if(performance_system2[0]==undefined){
                form.button(`§l${config['AppName'][0]}\n§r§0-`);
            }else{
                form.button(`§l${config['AppName'][0]}§r\n${performance_system2[random_performance][2]}`);
            }
            form.button(`§1>>>§0${config['AppName'][15]}§4<<<\n`);
            form.button(`§9${config['AppName'][1]}\n§0残高:§s${score}`);
            form.button(`§1${config['AppName'][2]}`);
            form.button(`§3${config['AppName'][3]}`);
            form.button(`§5${config['AppName'][4]}`);
            form.button(`§2${config['AppName'][5]}`);
            form.button(`§3${config['AppName'][6]}`);
            form.button(`§5${config['AppName'][7]}`);
            form.button(`§9${config['AppName'][8]}`);
            form.button(`§4${config['AppName'][9]}`)
            form.button(`§2${config['AppName'][10]}`);
            form.button(`§9${config['AppName'][11]}`);
            form.button(`§s${config['AppName'][12]}`);
            form.button(`§1${config['AppName'][14]}`);
            if (player.hasTag('HARUPhoneOP')) {
                form.button(`§5${config['AppName'][13]}`);
            }
            form.show(player).then(r => {
                if (r.canceled) return;
                let response = r.selection;
                switch (response) {
                    case 0:
                        if(performance_system2[0]==undefined){
                            player.sendMessage(`§r[§bbrowser§r] §a広告データが見つかりません`)
                            player.playSound("random.toast", {
                                pitch: 0.4, 
                                volume: 1.0
                            });  
                            return;
                        }
                        var form = new ActionFormData();
                        form.title(`${config['main'][0]}`);
                        form.body(`§l${performance_system2[random_performance][3]}\n§e------------\n§r投稿者:§a${performance_system2[random_performance][0]}\n§e§l------------\n§r${performance_system2[random_performance][4]}\n\n${performance_system2[random_performance][5]}\n\n${performance_system2[random_performance][6]}\n\n${performance_system2[random_performance][7]}`);
                        form.button(`閉じる`);
                        form.show(player).then(r => {
                            if (r.canceled) return;
                        })
                    break;
                    case 1:
                        App(eventData)
                    break;
                    case 2:
                        //money取得
                         var score = world.scoreboard.getObjective("money").getScore(player.scoreboardIdentity);
                        //HARUPAY画面
                        var form = new ActionFormData();
                        form.title(`${config['main'][0]}`);
                        form.body(`§b§l${time}\n\n§r§6 >>>§a所持金§r:§s${score}`);
                        form.button(`§l戻る`,'textures/ui/icon_import.png');
                        form.button("§9送る");
                        form.button("§5チャージ");
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0:
                                    //戻る
                                    HARUPhone1(eventData)
                                break;
                                case 1:
                                    //全プレイヤー取得
                                    player_Cash_Data[player.id].players = world.getAllPlayers()
                                    //HARIPAY送信画面
                                    form = new ActionFormData();
                                    form.body(`§b§l${time}\n\n§r§5 >>>§r送り先のプレイヤーを選択`);
                                    for (let i = 0; i < player_Cash_Data[player.id].players.length; i++){
                                        form.button(`§1${player_Cash_Data[player.id].players[i].name}\n§4>>>§8${player_Cash_Data[player.id].players[i].id}`);
                                    }
                                    form.show(player).then(r => {
                                        if (r.canceled) {
                                            return;
                                        };
                                        //送信先プレイヤーの設定
                                        player_Cash_Data[player.id].select_player = player_Cash_Data[player.id].players[r.selection]
                                        //送金額設定画面
                                        form = new ModalFormData();
                                        form.textField(`§b§l${time}\n\n§r§b送金額§r(半角数字)`, "0")
                                        form.show(player).then(r => {
                                            if (r.canceled) {
                                                return;
                                            };
                                            if(isNaN(r.formValues[0])){
                                                player.sendMessage(`§r[§bHARUPAY§r] §4半角数字で入力してください`)
                                                player.playSound("random.toast", {
                                                    pitch: 0.4, 
                                                    volume: 1.0
                                                });  
                                                return;
                                            }
                                            if (r.formValues[0]>100000000){
                                                player.sendMessage(`§r[§bHARUPAY§r] §4設定した金額は上限をオーバーしています.1億以下で設定してください`)
                                                player.playSound("random.toast", {
                                                    pitch: 0.4, 
                                                    volume: 1.0
                                                });  
                                                return;
                                            }
                                            if (r.formValues[0]<0){
                                                player.sendMessage(`§r[§bHARUPAY§r] §40以下は設定できません`)
                                                player.playSound("random.toast", {
                                                    pitch: 0.4, 
                                                    volume: 1.0
                                                });  
                                                return;
                                            }
                                            //送金額を保存
                                            if(r.formValues[0]=='') {
                                                player_Cash_Data[player.id].select_money = 0
                                            }else{
                                                player_Cash_Data[player.id].select_money = Number(r.formValues[0])
                                            }
                                            //playerの残高の取得
                                            player_Cash_Data[player.id].money = world.scoreboard.getObjective("money").getScore(player.scoreboardIdentity);

                                            var form = new ActionFormData();
                                            form.title("HARUPhone2");
                                            form.body(`§b§l${time}§r\n\n§a送信先プレイヤー§r:§b${player_Cash_Data[player.id].select_player.name} \n§e送金額§r:§b${player_Cash_Data[player.id].select_money}\n\n§1///////////////////\n§r処理後残高\n§5>>>§u${player_Cash_Data[player.id].money}§r-§2${player_Cash_Data[player.id].select_money}\n§r=§b${player_Cash_Data[player.id].money-player_Cash_Data[player.id].select_money}\n§1///////////////////`);
                                            form.button(`§s送金`);
                                            form.button(`キャンセル`);
                                            form.show(player).then(r => {
                                               if (r.canceled) return;
                                               switch (r.selection) {
                                                   case 0:
                                                    //playerの残高の取得
                                                    player_Cash_Data[player.id].money = world.scoreboard.getObjective("money").getScore(player.scoreboardIdentity);
                                                    if(player_Cash_Data[player.id].money >= player_Cash_Data[player.id].select_money){
                                                        //マネー操作
                                                        player.runCommand(`scoreboard players remove @s money ${player_Cash_Data[player.id].select_money}`)
                                                        player_Cash_Data[player.id].select_player.runCommand(`scoreboard players add @s money ${player_Cash_Data[player.id].select_money}`)
                                                        
                                                        //メッセージ
                                                        player.sendMessage(`§r[§bHARUPAY§r] §a${player_Cash_Data[player.id].select_player.name}§rへ§b${player_Cash_Data[player.id].select_money}§rPAY送信されました`)
                                                        player_Cash_Data[player.id].select_player.sendMessage(`§r[§bHARUPAY§r] §a${player.name}§rから§b${player_Cash_Data[player.id].select_money}§rPAY受け取りました`)
                                                        
                                                        //通知音
                                                        player.playSound("random.toast", {
                                                            pitch: 1.7, 
                                                            volume: 1.0
                                                        });
                                                        player_Cash_Data[player.id].select_player.playSound("random.toast", {
                                                            pitch: 1.7, 
                                                            volume: 1.0
                                                        });

                                                        //ログ関連
                                                        logs['harupay'].push([time,player.name,player_Cash_Data[player.id].select_player.name,player_Cash_Data[player.id].select_money])
                                                    }else{
                                                        player.sendMessage(`§r[§bHARUPAY§r] §4Moneyが不足しています`)
                                                        player.playSound("random.toast", {
                                                            pitch: 0.4, 
                                                            volume: 1.0
                                                        });  
                                                    }
                                                   break;
                                               }
                                            })
                                        })
                                    })
                                break;
                                case 2:
                                    //HAURPAYチャージ画面
                                    var form = new ModalFormData();
                                    form.textField("チャージ金額(半角数字)", "0") 
                                    form.show(player).then(r => {
                                        if (r.canceled) {
                                            return;
                                        };
                                        if(isNaN(r.formValues[0])){
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(HARUPAY)§r] §4半角数字で入力してください"}]}`)
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                        if (r.formValues[0]<0){
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(HARUPAY)§r] §40以下は設定できません"}]}`)
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                        var selection_score_charge = 0
                                        if(r.formValues[0]=='') {selection_score_charge=0}else{
                                            selection_score_charge=r.formValues[0]
                                         }
                                        player.runCommand(`scoreboard players add @s[hasitem={item=additem:hyoutaroucoin,quantity=${selection_score_charge / 100}..}] money ${selection_score_charge}`)
                                        player.runCommand(`tellraw @s[hasitem={item=additem:hyoutaroucoin,quantity=${selection_score_charge / 100}..}] {"rawtext":[{"text":"§r[§a通知§7(HARUPAY)§r] §a${selection_score_charge}PAYチャージしました"}]}`)
                                        player.runCommand(`tellraw @s[hasitem={item=additem:hyoutaroucoin,quantity=..${(selection_score_charge / 100)-1}}] {"rawtext":[{"text":"§r[§a通知§7(HARUPAY)§r] §4コインが不足しています"}]}`)
                                        player.runCommand(`tag @s[hasitem={item=additem:hyoutaroucoin,quantity=${selection_score_charge / 100}..}] add harupaymoneysystem2`)
                                        player.runCommand(`playsound random.toast @s[hasitem={item=additem:hyoutaroucoin,quantity=${selection_score_charge / 100}..}] ~ ~ ~ 1.0 1.7 1.0`)
                                        player.runCommand(`playsound random.toast @s[hasitem={item=additem:hyoutaroucoin,quantity=..${(selection_score_charge / 100)-1}}] ~ ~ ~ 1.0 0.4 0.7`)
                                        player.runCommand(`clear @s[hasitem={item=additem:hyoutaroucoin,quantity=${selection_score_charge / 100}..}] additem:hyoutaroucoin 0 ${selection_score_charge / 100}`)
                                        player.runCommand(`tag @s remove harupaymoneysystem2`)
                                    })
                                break;
                                default:
                            }
                        })
                    break;
                    case 3:  
                    // shop_menu をグローバル変数として初期化
                    var shop_menu = loadShopMenu();
                        
                        // 以下は元のコード全体に永続化処理を追加
                        player_Cash_Data[player.id].money = world.scoreboard.getObjective("money").getScore(player.scoreboardIdentity);
                        
                        var form = new ActionFormData();
                        form.title(`${config['main'][0]}`);
                        form.body(`§b§l${time}\n\n§r§6 >>>§a所持金§r:§s${player_Cash_Data[player.id].money}`);
                        form.button(`§l戻る`, 'textures/ui/icon_import.png');
                        form.button(`§1購入`);
                        form.button(`§5出品`);
                        form.button(`§r商品の§4削除`);
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0:
                                    // 戻る
                                    HARUPhone1(eventData);
                                    break;
                                case 1:
                                    if (shop_menu[0].length == 0) {
                                        player.sendMessage(`§r[§bQuick§r] §a商品が見つかりませんでした`);
                                        player.playSound("random.toast", {
                                            pitch: 0.4,
                                            volume: 1.0
                                        });
                                        return;
                                    }
                                    var form = new ActionFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.body("商品一覧");
                                    for (let i = 0; i < shop_menu[0].length; i++) {
                                        form.button(`§0${shop_menu[0][i][0]}\n§r金額:§s${shop_menu[0][i][2]}§rPAY  出品者:§2${shop_menu[0][i][1]}`);
                                    }
                                    form.show(player).then(r => {
                                        if (r.canceled) {
                                            return;
                                        }
                                        // 選択した商品を保存
                                        player_Cash_Data[player.id].select_shop = shop_menu[0][r.selection];
                                        // money取得
                                        player_Cash_Data[player.id].money = world.scoreboard.getObjective("money").getScore(player.scoreboardIdentity);
                        
                                        var form = new ActionFormData();
                                        form.title(`${config['main'][0]}`);
                                        form.body(`商品名:§a${player_Cash_Data[player.id].select_shop[0]}\n§r詳細:§c${player_Cash_Data[player.id].select_shop[3]}\n§r金額:§b${player_Cash_Data[player.id].select_shop[2]}  §r出品者:§2${player_Cash_Data[player.id].select_shop[1]}\n\n§e購入後自動的に料金が支払われます\n\n§1///////////////////\n§r処理後残高\n§5>>>§u${player_Cash_Data[player.id].money}§r-§2${player_Cash_Data[player.id].select_shop[2]}\n§r=§b${player_Cash_Data[player.id].money - player_Cash_Data[player.id].select_shop[2]}\n§1///////////////////`);
                                        form.button("§5この商品を買う");
                                        form.button("§1キャンセル");
                                        form.show(player).then(r => {
                                            if (r.canceled) {
                                                return;
                                            }
                                            switch (r.selection) {
                                                case 0:
                                                    player_Cash_Data[player.id].shop_stop = false;
                                                    // オンラインプレイヤー取得
                                                    player_Cash_Data[player.id].players = world.getAllPlayers();
                                                    for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
                                                        if (player_Cash_Data[player.id].select_shop[4] == player_Cash_Data[player.id].players[i].id) {
                                                            player_Cash_Data[player.id].shop_stop = true;
                                                            player_Cash_Data[player.id].select_player = player_Cash_Data[player.id].players[i];
                                                        }
                                                    }
                                                    if (player_Cash_Data[player.id].shop_stop == false) {
                                                        player.sendMessage(`§r[§bQuick§r] §4現在販売者がオフラインの為販売を中止します`);
                                                        player.playSound("random.toast", {
                                                            pitch: 0.4,
                                                            volume: 1.0
                                                        });
                                                        return;
                                                    }
                        
                                                    if (shop_menu[1][0] != undefined) {
                                                        for (let i = 0; i < shop_menu[1].length; i++) {
                                                            if (player_Cash_Data[player.id].select_shop[5] == shop_menu[1][i]) {
                                                                player_Cash_Data[player.id].shop_stop = false;
                                                            }
                                                        }
                                                    }
                        
                                                    if (player_Cash_Data[player.id].shop_stop == false) {
                                                        player.sendMessage(`§r[§bQuick§r] §4選択した商品は既に販売終了しております`);
                                                        player.playSound("random.toast", {
                                                            pitch: 0.4,
                                                            volume: 1.0
                                                        });
                                                        return;
                                                    }
                                                    // 残高が設定金額以上の場合のみ実行
                                                    if (player_Cash_Data[player.id].money >= player_Cash_Data[player.id].select_shop[2]) {
                                                        // マネー操作
                                                        player_Cash_Data[player.id].select_player.runCommand(`scoreboard players add @s money ${player_Cash_Data[player.id].select_shop[2]}`);
                                                        player.runCommand(`scoreboard players remove @s money ${player_Cash_Data[player.id].select_shop[2]}`);
                        
                                                        // メッセージ関連
                                                        player.sendMessage(`§r[§bQuick§r] §b${player_Cash_Data[player.id].select_shop[1]}へ${player_Cash_Data[player.id].select_shop[2]}PAY支払いました`);
                                                        player_Cash_Data[player.id].select_player.sendMessage(`§r[§bQuick§r] §b${player.name}§rが§b${player_Cash_Data[player.id].select_shop[0]}§rを§e注文しました`);
                                                        player_Cash_Data[player.id].select_player.sendMessage(`§r[§bQuick§r] §e${player.name}から${player_Cash_Data[player.id].select_shop[2]}PAY受け取りました`);
                        
                                                        // 通知音
                                                        player.playSound("random.toast", {
                                                            pitch: 1.7,
                                                            volume: 1.0
                                                        });
                                                        player_Cash_Data[player.id].select_player.playSound("random.toast", {
                                                            pitch: 1.7,
                                                            volume: 1.0
                                                        });
                        
                                                        // log関連
                                                        logs['quick'].push([time, player.name, player_Cash_Data[player.id].select_shop[1], player_Cash_Data[player.id].select_shop[2]]);
                        
                                                        // 商品の削除/販売済み商品に追加
                                                        shop_menu[1].push(player_Cash_Data[player.id].select_shop[5]);
                                                        for (let i = 0; i < shop_menu[0].length; i++) {
                                                            if (shop_menu[0][i][5] === player_Cash_Data[player.id].select_shop[5]) {
                                                                shop_menu[0].splice(i, 1);
                                                            }
                                                        }
                                                        saveShopMenu(shop_menu); // 更新後に保存
                                                    } else {
                                                        player.sendMessage(`§r[§bQuick§r] §cHARUPAY残高が不足しています`);
                                                        player.playSound("random.toast", {
                                                            pitch: 0.4,
                                                            volume: 1.0
                                                        });
                                                    }
                                                    break;
                                            }
                                        }).catch(e => {
                                            console.error(e, e.stack);
                                        });
                                    }).catch(e => {
                                        console.error(e, e.stack);
                                    });
                                    break;
                                case 2:
                                    var form = new ModalFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.textField("商品名", "丸石");
                                    form.textField("詳細", "エンチャント内容など");
                                    form.textField("販売額(半角数字)", "0");
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        if (isNaN(r.formValues[2])) {
                                            player.sendMessage(`§r[§bQuick§r] §4半角数字で入力してください`);
                                            player.playSound("random.toast", {
                                                pitch: 0.4,
                                                volume: 1.0
                                            });
                                            return;
                                        }
                                        if (r.formValues[2] > 100000000) {
                                            player.sendMessage(`§r[§bQuick§r] §41億以下で設定してください`);
                                            player.playSound("random.toast", {
                                                pitch: 0.4,
                                                volume: 1.0
                                            });
                                            return;
                                        }
                                        if (r.formValues[2] < 0) {
                                            player.sendMessage(`§r[§bQuick§r] §40以下は設定できません`);
                                            player.playSound("random.toast", {
                                                pitch: 0.4,
                                                volume: 1.0
                                            });
                                            return;
                                        }
                                        if (r.formValues[0] == '') {
                                            player.sendMessage(`§r[§bQuick§r] §4商品名が未入力です`);
                                            player.playSound("random.toast", {
                                                pitch: 0.4,
                                                volume: 1.0
                                            });
                                            return;
                                        }
                        
                                        if (r.formValues[2] == '') {
                                            var selection_score_quick = 0;
                                        } else {
                                            var selection_score_quick = Number(r.formValues[2]);
                                        }
                        
                                        // Code生成
                                        let number = '';
                                        for (let i = 0; i < 8; i++) {
                                            number += Math.floor(Math.random() * 10); // 0〜9のランダムな数字
                                        }
                                        shop_menu[0].push([r.formValues[0], player.name, selection_score_quick, r.formValues[1], player.id, number]);
                        
                                        // オンラインプレイヤー取得
                                        player_Cash_Data[player.id].players = world.getAllPlayers();
                        
                                        for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
                                            player_Cash_Data[player.id].players[i].sendMessage(`§r[§bQuick§r] §a${r.formValues[0]}§r:§b${selection_score_quick}§rPAYの販売が開始されました`);
                                            // 通知サウンド
                                            player_Cash_Data[player.id].players[i].playSound("random.toast", {
                                                pitch: 1.7,
                                                volume: 1.0
                                            });
                                        }
                                        saveShopMenu(shop_menu); // 出品後に保存
                                    }).catch(e => {
                                        console.error(e, e.stack);
                                    });
                                    break;
                                case 3:
                                    if (shop_menu[0].length == 0) {
                                        player.sendMessage(`§r[§bQuick§r] §a削除できる商品が見つかりませんでした`);
                                        player.playSound("random.toast", {
                                            pitch: 0.4,
                                            volume: 1.0
                                        });
                                        return;
                                    }
                                    player_Cash_Data[player.id].my_shop = [];
                                    var form = new ActionFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.body("削除する商品を選択");
                                    for (let i = 0; i < shop_menu[0].length; i++) {
                                        if (player.id == shop_menu[0][i][4]) {
                                            form.button(`§l${shop_menu[0][i][0]}\n§r額:§b${shop_menu[0][i][2]}§rPAY  出品者:§2${shop_menu[0][i][1]}`);
                                            player_Cash_Data[player.id].my_shop.push(shop_menu[0][i]);
                                        }
                                    }
                                    if (player_Cash_Data[player.id].my_shop.length == 0) { // lengthが-1にならないよう修正
                                        player.sendMessage(`§r[§bQuick§r] §a削除できる商品が見つかりませんでした`);
                                        player.playSound("random.toast", {
                                            pitch: 0.4,
                                            volume: 1.0
                                        });
                                        return;
                                    }
                                    form.show(player).then(r => {
                                        if (r.canceled) {
                                            return;
                                        }
                                        for (let i = 0; i < shop_menu[0].length; i++) {
                                            if (shop_menu[0][i][5] === player_Cash_Data[player.id].my_shop[r.selection][5]) {
                                                shop_menu[0].splice(i, 1);
                                            }
                                        }
                                        player.sendMessage(`§r[§bQuick§r] §a削除しました`);
                                        player.playSound("random.toast", {
                                            pitch: 1.7,
                                            volume: 1.0
                                        });
                                        saveShopMenu(shop_menu); // 削除後に保存
                                        return;
                                    }).catch(e => {
                                        console.error(e, e.stack);
                                    });
                                    break;
                            }
                        }).catch(e => {
                            console.error(e, e.stack);
                        });
                    break;
                    case 4:
                        //メール

                            //オンラインプレイヤー取得
                            player_Cash_Data[player.id].players = world.getAllPlayers()

                            //送信先プレイヤー選択画面
                            var form = new ActionFormData();
                            form.title(`${config['main'][0]}`);
                            form.body(`§l§b${time}§r\n\n§6 >>>§s送信先プレイヤーを選択`);
                            form.button(`§l戻る`,'textures/ui/icon_import.png');
                            for (let i = 0; i <  player_Cash_Data[player.id].players.length; i++){
                                form.button(`§1${ player_Cash_Data[player.id].players[i].name}\n§4>>>§8${ player_Cash_Data[player.id].players[i].id}`);
                            }
                            form.show(player).then(r => {
                                if (r.canceled){ 
                                    return
                                };
                                //戻る
                                if(r.selection==0){
                                    //戻る
                                    HARUPhone1(eventData)
                                    return;
                                }

                                //↓プレイヤー選択
                                if(player.id===player_Cash_Data[player.id].players[r.selection-1].id){
                                    player.sendMessage(`§r[§bメール§r] §c自分は選択できません`)
                                    player.playSound("random.toast", {
                                        pitch: 0.4, 
                                        volume: 1.0
                                    });  
                                    return;
                                }
                                //選択したプレイヤーを保存
                                player_Cash_Data[player.id].player_select = player_Cash_Data[player.id].players[r.selection-1];
                                  //メッセージ入力画面
                                    var form = new ModalFormData()
                                        form.title(`${config['main'][0]}`);
                                        form.textField(`§l§b${time}§r\n\n§6>>>§r送信先:§a${player_Cash_Data[player.id].player_select.name}`, "メッセージ入力")
                                        form.toggle(`§b座標共有 §r(false/true)`, false)
                                        form.show(player).then(r => {
                                            if (r.canceled){ 
                                                return
                                            };
                                            if(r.formValues[0] == '' && r.formValues[1]==false){
                                                player.sendMessage(`§r[§bメール§r] §4メッセージ未入力です`)
                                                player.playSound("random.toast", {
                                                    pitch: 0.4, 
                                                    volume: 1.0
                                                });  
                                                return;
                                            } 
                                            //現在地を取得
                                            player_Cash_Data[player.id].player_location = player.location;
                                                //メッセージ送信
                                              if(r.formValues[0] !== ''){
                                                player.sendMessage(`§r[§bメール§r] §a${player_Cash_Data[player.id].player_select.name}§rへ送信§6>>>§r${r.formValues[0]}`)
                                                player_Cash_Data[player.id].player_select.sendMessage(`§r[§bメール§r] §a${player.name}§rから受信§6>>>§r${r.formValues[0]}`)
                                              }
                                              if(r.formValues[1]==true){
                                                player.sendMessage(`§r[§bメール§r] §c座標送信§r(${player.name})§r:§b${Math.round(player_Cash_Data[player.id].player_location.x)},${Math.round(player_Cash_Data[player.id].player_location.y)},${Math.round(player_Cash_Data[player.id].player_location.z)}`)
                                                player_Cash_Data[player.id].player_select.sendMessage(`§r[§bメール§r] §c座標受信§r(${player.name})§r:§b${Math.round(player_Cash_Data[player.id].player_location.x)},${Math.round(player_Cash_Data[player.id].player_location.y)},${Math.round(player_Cash_Data[player.id].player_location.z)}`)
                                              }
                                                //通知サウンド
                                                player.playSound("random.toast", {
                                                    pitch: 1.7, 
                                                    volume: 1.0
                                                });  
                                                player_Cash_Data[player.id].player_select.playSound("random.toast", {
                                                    pitch: 1.7, 
                                                    volume: 1.0
                                                });  
                                        })
                                        
                            })
                    break;
                    case 5:
                        //オープンチャット送信画面
                        var form = new ModalFormData();
                        form.title(`${config['main'][0]}`);
                        form.textField(`§l§b${time}§r\n\nチャット`, "メッセージ")
                        form.toggle(`§a座標共有 §r(false/true)`, false)
                        form.show(player).then(r => {
                            if (r.canceled) return;

                            if(r.formValues[0] == '' && r.formValues[1]==false){
                                player.sendMessage(`§r[§bオープンチャット§r] §4メッセージ未入力です`)
                                player.playSound("random.toast", {
                                    pitch: 0.4, 
                                    volume: 1.0
                                });  
                                return;
                            } 
                            //オンラインプレイヤー取得
                            player_Cash_Data[player.id].players = world.getAllPlayers()
                            //現在地を取得
                            player_Cash_Data[player.id].player_location = player.location;

                            for (let i = 0; i < player_Cash_Data[player.id].players.length; i++){
                               if(r.formValues[0] !== ''){
                                player_Cash_Data[player.id].players[i].sendMessage(`§r[§bチャット§r] §a${player.name}§b:§r${r.formValues[0]}`)
                               }
                               if(r.formValues[1]==true){
                                player_Cash_Data[player.id].players[i].sendMessage(`§r[§bチャット§r] §c座標§r(${player.name})§r:§b${Math.round(player_Cash_Data[player.id].player_location.x)},${Math.round(player_Cash_Data[player.id].player_location.y)},${Math.round(player_Cash_Data[player.id].player_location.z)}`)
                               } 

                               //通知サウンド
                                player_Cash_Data[player.id].players[i].playSound("random.toast", {
                                  pitch: 1.7, 
                                  volume: 1.0
                                });  
                            }  
                        }).catch(e => {
                            console.error(e, e.stack);
                        });
                    break;
                    case 6:
                        //仕事依頼設定画面
                        form = new ActionFormData();
                        form.title(`${config['main'][0]}`);
                        form.body(`§l§b${time}§r\n\n§5 >>>§rサービスを選択`);
                        form.button(`§l戻る`,'textures/ui/icon_import.png');
                        form.button("§1募集");
                        form.button("§5探す");
                        form.button("募集の§4削除");
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0:
                                    //戻る
                                    HARUPhone1(eventData)
                                break;
                                case 1:
                                    var form = new ModalFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.textField("仕事ジャンル", "例:整地")
                                    form.textField("仕事内容", "例:約半径30ブロックの整地")
                                    form.textField("報酬額(半角数字)", "0") 
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        if (r.formValues[2]>100000000){
                                            player.sendMessage(`§r[§b仕事依頼§r] §4設定した金額は上限をオーバーしています.1億以下で設定してください`)
                                                player.playSound("random.toast", {
                                                    pitch: 0.4, 
                                                    volume: 1.0
                                                });  
                                            return;
                                        }
                                        if ((r.formValues[0]==''||r.formValues[2]=='')){
                                            player.sendMessage(`§r[§b仕事依頼§r] §4設定されていない項目があるため開始できませんでした`)
                                                player.playSound("random.toast", {
                                                    pitch: 0.4, 
                                                    volume: 1.0
                                                });  
                                            return;
                                        }
                                        if (r.formValues[2]<0){
                                            player.sendMessage(`§r[§b仕事依頼§r] §40以下は設定できません`)
                                                player.playSound("random.toast", {
                                                    pitch: 0.4, 
                                                    volume: 1.0
                                                });  
                                            return;
                                        }
                                        player_Cash_Data[player.id].players = world.getAllPlayers()
                                        for (let i = 0; i < player_Cash_Data[player.id].players.length; i++){
                                            player_Cash_Data[player.id].players[i].sendMessage(`§r[§b仕事依頼§r] §b${player.name}§aが§b${r.formValues[1]}§aの募集しました`)
                                            player_Cash_Data[player.id].players[i].sendMessage(`§5>>>§a報酬額§r:§b${r.formValues[2]}`)
                                            player_Cash_Data[player.id].players[i].playSound("random.toast", {
                                                pitch: 1.7, 
                                                volume: 1.0
                                            });  
                                        }
                                        //Code生成
                                        let number = '';
                                        for (let i = 0; i < 8; i++) {
                                           number += Math.floor(Math.random() * 10); // 0〜9のランダムな数字
                                        }
                                        quest[0].push([r.formValues[0],player.name,r.formValues[2],r.formValues[1],player.id,number])

                                    }).catch(e => {
                                        console.error(e, e.stack);
                                    });
                                break;
                                case 2:
                                    if(quest[0].length==0){
                                        player.sendMessage(`§r[§b仕事依頼§r] §a募集が見つかりませんでした`)
                                        player.playSound("random.toast", {
                                             pitch: 0.4, 
                                             volume: 1.0
                                        });  
                                        return;
                                    };
                                    var form = new ActionFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.body("仕事一覧");
                                    for (let i = 0; i < quest[0].length; i++){
                                        form.button(`§0${quest[0][i][0]}\n§r報酬額:§s${quest[0][i][2]}§rPAY  依頼者:§2${quest[0][i][1]}`);
                                    }
                                    form.show(player).then(r => {
                                        if (r.canceled) {
                                            return;
                                        };
                                        //選択した商品を保存
                                        player_Cash_Data[player.id].select_quest = quest[0][r.selection];

                                        var form = new ActionFormData();
                                        form.title(`${config['main'][0]}`);
                                        form.body(`仕事:§a${player_Cash_Data[player.id].select_quest[0]}\n§r詳細:§c${player_Cash_Data[player.id].select_quest[3]}\n§r金額:§b${player_Cash_Data[player.id].select_quest[2]}  §r依頼者:§2${player_Cash_Data[player.id].select_quest[1]}`);
                                        form.button("§5仕事を受ける");
                                        form.button("§1キャンセル");
                                        form.show(player).then(r => {
                                            if (r.canceled) {
                                                return;
                                            }
                                            switch (r.selection) {
                                                    case 0:
                                                        player_Cash_Data[player.id].quest_stop = false
                                                        //オンラインプレイヤー取得
                                                        player_Cash_Data[player.id].players = world.getAllPlayers()
                                                        for (let i = 0; i < player_Cash_Data[player.id].players.length; i++){
                                                            if(player_Cash_Data[player.id].select_quest[4]==player_Cash_Data[player.id].players[i].id){
                                                                player_Cash_Data[player.id].quest_stop = true
                                                                player_Cash_Data[player.id].select_player = player_Cash_Data[player.id].players[i]
                                                            }    
                                                        }
                                                        if(player_Cash_Data[player.id].quest_stop == false){
                                                          player.sendMessage(`§r[§b仕事依頼§r] §4現在募集者がオフラインの為処理を中止します`)
                                                          player.playSound("random.toast", {
                                                               pitch: 0.4, 
                                                               volume: 1.0
                                                          });
                                                          return;
                                                        }
            
                                                        if(quest[1][0]!=undefined){
                                                        for (let i = 0; i < quest[1].length; i++){
                                                            if(player_Cash_Data[player.id].select_quest[5]==quest[1][i]){
                                                                player_Cash_Data[player.id].quest_stop = false
                                                            }
                                                        }
                                                        }
            
                                                        if(player_Cash_Data[player.id].quest_stop == false){
                                                            player.sendMessage(`§r[§b仕事依頼§r] §4選択した募集は既に終了しております`)
                                                            player.playSound("random.toast", {
                                                                 pitch: 0.4, 
                                                                 volume: 1.0
                                                            });
                                                            return;
                                                        }     
                                                         //メッセージ関連
                                                         player_Cash_Data[player.id].select_player.sendMessage(`§r[§b仕事依頼§r] §e${player.name}§bが${player_Cash_Data[player.id].select_quest[0]}の仕事募集を受けました`)
                                                         player_Cash_Data[player.id].select_player.sendMessage(`§r[§b仕事依頼§r] §b${player_Cash_Data[player.id].select_quest[0]}§aの仕事を受けました §c募集者§r:§e${player_Cash_Data[player.id].select_quest[1]}`)     
                                                         
                                                         //通知音
                                                         player.playSound("random.toast", {
                                                             pitch: 1.7, 
                                                             volume: 1.0
                                                         });
                                                         player_Cash_Data[player.id].select_player.playSound("random.toast", {
                                                             pitch: 1.7, 
                                                             volume: 1.0
                                                         });
         
                                                         //log関連
                                                         logs['quest'].push([time,player.name,player_Cash_Data[player.id].select_quest[1],player_Cash_Data[player.id].select_quest[0]])

                                                         quest[1].push(player_Cash_Data[player.id].select_quest[5])
                                                         for (let i = 0; i < quest[0].length; i++){
                                                             if(quest[0][i][5]===player_Cash_Data[player.id].select_quest[5]){
                                                                 quest[0].splice(i, 1);
                                                             }
                                                         }
                                                    break;
                                                }
                                            })
                                    }).catch(e => {
                                        console.error(e, e.stack);
                                    });
                                break;
                                case 3:
                                    if(quest[0].length==0){
                                        player.sendMessage(`§r[§b仕事依頼§r] §a削除できる募集が見つかりませんでした`)
                                            player.playSound("random.toast", {
                                                pitch: 0.4, 
                                                volume: 1.0
                                            });  
                                        return;
                                    };
                                    player_Cash_Data[player.id].my_quest = []
                                    var form = new ActionFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.body("削除する商品を選択");
                                    for (let i = 0; i < quest[0].length; i++){
                                        if(player.id==quest[0][i][4]){
                                         form.button(`§l${quest[0][i][0]}\n§r額:§b${quest[0][i][2]}§rPAY  依頼者:§2${quest[0][i][1]}`);
                                         player_Cash_Data[player.id].my_quest.push(quest[0][i])
                                        }
                                    }
                                    if(player_Cash_Data[player.id].my_quest.length==-1){
                                        player.sendMessage(`§r[§b仕事依頼§r] §a削除できる募集が見つかりませんでした`)
                                            player.playSound("random.toast", {
                                                pitch: 0.4, 
                                                volume: 1.0
                                            });  
                                        return;
                                    };
                                    form.show(player).then(r => {
                                        if (r.canceled) {
                                            return;
                                        };
                                        for (let i = 0; i < quest[0].length; i++){
                                            if(quest[0][i][5]===player_Cash_Data[player.id].my_quest[r.selection][5]){
                                                quest[0].splice(i, 1);
                                            }
                                        }
                                        player.sendMessage(`§r[§b仕事依頼§r] §a削除しました`)
                                            player.playSound("random.toast", {
                                                pitch: 1.7, 
                                                volume: 1.0
                                            });  
                                        return;
                                    }).catch(e => {
                                        console.error(e, e.stack);
                                    });
                                break;
                                default:
                            }
                        })
                    break; 
                    case 7:
                    var form = new ActionFormData();
                    form.title(`${config['main'][0]}`);
                    form.body(`§l§b${time}§r\n\n §5>>>§a商品を見つける`);
                    form.button(`§l戻る`,'textures/ui/icon_import.png');
                    form.button(`§9キーワード検索`);
                    form.button(`§2会社指定`);
                    form.button(`§1注文した商品の配送状況`);
                    form.show(player).then(r => {
                        if (r.canceled) return;
                        let response = r.selection;
                        switch (response) {
                            case 0:
                                    //戻る
                                    HARUPhone1(eventData)
                            break;
                            case 1:
                                var advance_shop = world.getDynamicProperty('advance_shop')
                                    if(advance_shop==undefined){
                                        var advance_shop_system2=[]
                                    }else{
                                    var advance_shop_system2 = JSON.parse(advance_shop);
                                    }
                                    var advance_shop_cash = [[],[]]
                                    var advance_shop_cash1 = 0
                                    var advance_shop_cash2 = []
                                    var advance_shop_cash3 = []
                                    if(advance_shop==undefined||advance_shop_system2[0]==undefined){
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §a商品が見つかりませんでした"}]}`)
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                        return;
                                    }
                                    var form = new ModalFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.textField("検索商品", "ダイアモンド") 
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        if(r.formValues[0]==''){
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §4検索キーワードを入力してください"}]}`)
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                        var form = new ActionFormData();
                                        form.title("advance");
                                        form.body("検索商品リスト");
                                        for (let i = 0; i < advance_shop_system2.length; i++){
                                            advance_shop_cash[0].push(i)
                                            for (let i1 = 0; i1 < advance_shop_system2[i][1].length; i1++){
                                                if(advance_shop_system2[i][1][i1][0].indexOf(r.formValues[0])!=-1){
                                                    form.button(`§l${advance_shop_system2[i][1][i1][0]}\n§r金額:§9${advance_shop_system2[i][1][i1][1]} §r在庫:§2${advance_shop_system2[i][1][i1][2]}`);
                                                    advance_shop_cash1 = 1
                                                    advance_shop_cash2.push(i)
                                                    advance_shop_cash3.push(i1)
                                                }   
                                            }
                                        }
                                        if(advance_shop_cash1==0){
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §a商品が見つかりませんでした"}]}`)
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                        form.show(player).then(r => {
                                            if (r.canceled) return;
                                            let response = r.selection;
                                                advance_shop_cash[1].push(advance_shop_cash2[response])
                                                advance_shop_cash[1].push(response)
                                                advance_shop_cash[1].push(advance_shop_cash3[response])
                                                var form = new ModalFormData();
                                                form.title(`${config['main'][0]}`);
                                                form.textField("個数 (半角数字)", "0") 
                                                form.show(player).then(r => {
                                                    if (r.canceled) return;
                                                    advance_shop_cash[1].push(Number(r.formValues[0]))
                                                    if(r.formValues[0]<=0){
                                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §40以下は設定できません"}]}`)
                                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                        return;
                                                    }
                                                    if(r.formValues[0]==''){
                                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §4個数を入力してください"}]}`)
                                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                        return;
                                                    }
                                                    if(Number(r.formValues[0])>advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][2]){
                                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §4在庫数をオーバーしています"}]}`)
                                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                        return;
                                                    }
                                                    var form = new ActionFormData();
                                                    form.title(`${config['main'][0]}`);
                                                    form.body(`§l注文内容\n\n§r商品名:§a${advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][0]}\n§r個数:§a${advance_shop_cash[1][3]}§r合計金額:§b${advance_shop_cash[1][3]*advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][1]}\n\n§r販売元:§a${advance_shop_system2[advance_shop_cash[1][0]][0]}`);
                                                    form.button(`注文`)
                                                    form.button(`閉じる`)
                                                    form.show(player).then(r => {
                                                        if (r.canceled) return;
                                                        let response = r.selection;
                                                        switch (response) {
                                                            case 0:
                                                                const score = world.scoreboard.getObjective("money").getScore(player.scoreboardIdentity);
                                                                if(score>=advance_shop_cash[1][3]*advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][1]){
                                                                    var advance_partner = ''
                                                                    var advance_member = world.getDynamicProperty('advance_member')
                                                                    if(advance_member==undefined){
                                                                        var advance_member_system2=[]
                                                                    }else{
                                                                    var advance_member_system2 = JSON.parse(advance_member);
                                                                    }  
                                                                    for (let i = 0; i < advance_member_system2.length; i++){
                                                                        if(advance_member_system2[i][1]==advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][0]){
                                                                            advance_partner=`${advance_member_system2[i][0]}`
                                                                        }
                                                                    }   
                                                                advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][2]=advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][2]-advance_shop_cash[1][2]
                                                                advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][3].push([player.name,advance_shop_cash[1][3],0])
                                                                advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][4]=advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][4]+1
                                                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §a注文しました"}]}`)
                                                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                                player.runCommand(`tellraw @a[name="${advance_partner}"] {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §b${player.name}§aが§b${advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][0]} [${advance_shop_system2[advance_shop_cash[1][0]][0]}]§aを注文しました"}]}`)
                                                                player.runCommand(`playsound random.toast @a[name="${advance_partner}"] ~ ~ ~ 1.0 1.7 0.5`)
                                                                var advance_member = world.getDynamicProperty('advance_member')
                                                                var advance_member_system2 = JSON.parse(advance_member);
                                                                for (let i = 0; i < advance_member_system2.length; i++){
                                                                    if(advance_member_system2[i][1]==advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][0]){
                                                                        advance_member_system2[i][3]=advance_member_system2[i][3]+advance_shop_cash[1][3]*advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][1]
                                                                    }
                                                                }
                                                                const advance_shop_system3 = JSON.stringify(advance_shop_system2);
                                                                world.setDynamicProperty('advance_shop',advance_shop_system3)
                                                                const advance_member_system3 = JSON.stringify(advance_member_system2);
                                                                world.setDynamicProperty('advance_member',advance_member_system3)
                                                                player.runCommand(`scoreboard players remove @s money ${advance_shop_cash[1][3]*advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][1]}`)
                                                            }else{
                                                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §4所持金が不足しています"}]}`)
                                                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                            }
                                                            break;
                                                        }
                                                    })
                                                })
                                        })
                                    })
                            break;
                            case 2:
                                var advance_shop = world.getDynamicProperty('advance_shop')
                                    if(advance_shop==undefined){
                                        var advance_shop_system2=[]
                                    }else{
                                    var advance_shop_system2 = JSON.parse(advance_shop);
                                    }
                                    var advance_shop_cash = [[],[]]
                                    if(advance_shop==undefined||advance_shop_system2[0]==undefined){
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §a商品が見つかりませんでした"}]}`)
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                        return;
                                    }
                               var form = new ActionFormData();
                                form.title(`${config['main'][0]}`);
                                form.body("会社を指定して商品を探します");
                                for (let i = 0; i < advance_shop_system2.length; i++){
                                    form.button(`${advance_shop_system2[i][0]}§r`);
                                    advance_shop_cash[0].push(i)
                                }
                                form.show(player).then(r => {
                                    if (r.canceled) return;
                                    let response = r.selection;
                                    advance_shop_cash[1].push(response)
                                    var form = new ActionFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.body(`${advance_shop_system2[advance_shop_cash[0][response]][0]}の商品一覧`);
                                    for (let i = 0; i < advance_shop_system2[advance_shop_cash[0][response]][1].length; i++){
                                        form.button(`§l${advance_shop_system2[advance_shop_cash[0][response]][1][i][0]}\n§r金額:§9${advance_shop_system2[advance_shop_cash[0][response]][1][i][1]} §r在庫:§2${advance_shop_system2[advance_shop_cash[0][response]][1][i][2]}`);
                                    }
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        let response = r.selection;
                                        advance_shop_cash[1].push(response)
                                        var form = new ModalFormData();
                                        form.title(`${config['main'][0]}`);
                                        form.textField("個数 (半角数字)", "0") 
                                        form.show(player).then(r => {
                                            if (r.canceled) return;
                                            advance_shop_cash[1].push(r.formValues[0])
                                            if(r.formValues[0]<=0){
                                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §40以下は設定できません"}]}`)
                                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                return;
                                            }
                                            if(r.formValues[0]==''){
                                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §4個数を入力してください"}]}`)
                                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                return;
                                            }
                                            if(Number(r.formValues[0])>advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][2]){
                                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §4在庫数をオーバーしています"}]}`)
                                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                return;
                                            }
                                            var form = new ActionFormData();
                                            form.title(`${config['main'][0]}`);
                                            form.body(`§l注文内容\n\n§r商品名:§a${advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][0]}\n§r個数:§a${advance_shop_cash[1][2]}§r合計金額:§b${advance_shop_cash[1][2]*advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][1]}\n\n§r販売元:§a${advance_shop_system2[advance_shop_cash[1][0]][0]}`);
                                            form.button(`注文`)
                                            form.button(`閉じる`)
                                            form.show(player).then(r => {
                                                if (r.canceled) return;
                                                let response = r.selection;
                                                switch (response) {
                                                    case 0:
                                                        const score = world.scoreboard.getObjective("money").getScore(player.scoreboardIdentity);
                                                        if(score>=advance_shop_cash[1][2]*advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][1]){
                                                            var advance_partner = ''
                                                            var advance_member = world.getDynamicProperty('advance_member')
                                                            if(advance_member==undefined){
                                                                var advance_member_system2=[]
                                                            }else{
                                                            var advance_member_system2 = JSON.parse(advance_member);
                                                            }  
                                                            for (let i = 0; i < advance_member_system2.length; i++){
                                                                if(advance_member_system2[i][1]==advance_shop_system2[advance_shop_cash[1][0]][0]){
                                                                    advance_partner=`${advance_member_system2[i][0]}`
                                                                }
                                                            }                              
                                                        advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][2]=advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][2]-advance_shop_cash[1][2]
                                                        advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][3].push([player.name,advance_shop_cash[1][2],0])
                                                        advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][4]=advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][4]+1
                                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §a注文しました"}]}`)
                                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                        player.runCommand(`tellraw @a[name="${advance_partner}"] {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §b${player.name}§aが§b${advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][0]} [${advance_shop_system2[advance_shop_cash[1][0]][0]}]§aを注文しました"}]}`)
                                                        player.runCommand(`playsound random.toast @a[name="${advance_partner}"] ~ ~ ~ 1.0 1.7 0.5`)
                                                        var advance_member = world.getDynamicProperty('advance_member')
                                                        var advance_member_system2 = JSON.parse(advance_member);
                                                        for (let i = 0; i < advance_member_system2.length; i++){
                                                            if(advance_member_system2[i][1]==advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][0]){
                                                                advance_member_system2[i][3]=advance_member_system2[i][3]+advance_shop_cash[1][2]*advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][1]
                                                            }
                                                        }
                                                        const advance_shop_system3 = JSON.stringify(advance_shop_system2);
                                                        world.setDynamicProperty('advance_shop',advance_shop_system3)
                                                        const advance_member_system3 = JSON.stringify(advance_member_system2);
                                                        world.setDynamicProperty('advance_member',advance_member_system3)
                                                        player.runCommand(`scoreboard players remove @s money ${advance_shop_cash[1][2]*advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][1]}`)
                                                    }else{
                                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §4所持金が不足しています"}]}`)
                                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                    }
                                                    break;
                                                }
                                            })
                                        })
                                    })
                                })
                            break;
                            case 3:
                                var advance_shop_pattern = []
                                var advance_shop = world.getDynamicProperty('advance_shop')
                                if(advance_shop==undefined){
                                    var advance_shop_system2=[]
                                }else{
                                var advance_shop_system2 = JSON.parse(advance_shop);
                                }
                                for (let i = 0; i < advance_shop_system2.length; i++){
                                    for (let i1 = 0; i1 < advance_shop_system2[i][1].length; i1++){
                                        for (let i2 = 0; i2 < advance_shop_system2[i][1][i1][3].length; i2++){
                                          if(advance_shop_system2[i][1][i1][3][i2][0]==player.name){
                                            advance_shop_pattern.push([advance_shop_system2[i][1][i1][0],advance_shop_system2[i][1][i1][3][i2]])
                                          }
                                        }
                                    }
                                }
                                var advance_shop_pattern_text = ''
                                for (let i = 0; i < advance_shop_pattern.length; i++){
                                    if(advance_shop_pattern[i][1][2]==0){
                                        var advance_shop_pattern_text_cash = '§9現在配送中です'
                                    }else{
                                        var advance_shop_pattern_text_cash = '§9配送完了'
                                    }
                                    advance_shop_pattern_text = advance_shop_pattern_text+`商品名:§b${advance_shop_pattern[i][0]}§r 個数:§a${advance_shop_pattern[i][1][1]}\n${advance_shop_pattern_text_cash}§r\n`
                                }
                                var form = new ActionFormData();
                                form.title(`${config['main'][0]}`);
                                form.body(`${advance_shop_pattern_text}`);
                                form.button(`閉じる`);
                                form.show(player).then(r => {
                                    if (r.canceled) return;
                                })
                            break;
                        }
                    })
                    break;
                    case 8:
                        var kannkin_information = world.getDynamicProperty('kannkin_information')
                            if(kannkin_information==undefined){
                                var kannkin_information_system2=[]
                            }else{
                            var kannkin_information_system2 = JSON.parse(kannkin_information);
                            }
                            if(kannkin_information_system2[0]==undefined){
                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(換金)§r] §4アイテムが見つかりません"}]}`)
                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                return;
                            }
                            var form = new ActionFormData();
                            form.title(`${config['main'][0]}`);
                            form.body("換金するアイテムを選択");
                            for (let i = 0; i < kannkin_information_system2.length; i++){
                                form.button(`${kannkin_information_system2[i][0]} 1個/§b${kannkin_information_system2[i][1]}§r`,`textures/${kannkin_information_system2[i][3]}`);
                            }
                            form.show(player).then(r => {
                                if (r.canceled) {  
                                    return;
                                }
                                player_Cash_Data[player.id].select_item = r.selection;
                                var form = new ModalFormData();
                                form.textField("換金数(半角数字)", "0") 
                                form.show(player).then(r => {
                                    if (r.canceled) {  
                                        return;
                                    }
                                    if (r.formValues[0]<0){
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(換金)§r] §40以下は設定できません"}]}`)
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                        return;
                                    }
                                    if (r.formValues[0]==''){
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(換金)§r] §4換金数を設定してください"}]}`)
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                        return;
                                    }
                                    player.runCommand(`tellraw @s[hasitem={item=${kannkin_information_system2[player_Cash_Data[player.id].select_item][2]},quantity=..${r.formValues[0]-1}}]{"rawtext":[{"text":"§r[§a通知§7(換金)§r] §4アイテム数が足りません"}]}`)
                                    player.runCommand(`playsound random.toast @s[hasitem={item=${kannkin_information_system2[player_Cash_Data[player.id].select_item][2]},quantity=..${r.formValues[0]-1}}] ~ ~ ~ 1.0 0.4 0.7`)
                                    player.runCommand(`tellraw @s[hasitem={item=${kannkin_information_system2[player_Cash_Data[player.id].select_item][2]},quantity=${r.formValues[0]}..}]{"rawtext":[{"text":"§r[§a通知§7(換金)§r] §e換金し${kannkin_information_system2[player_Cash_Data[player.id].select_item][1]*r.formValues[0]}PAY取得しました"}]}`)
                                    player.runCommand(`playsound random.toast @s[hasitem={item=${kannkin_information_system2[player_Cash_Data[player.id].select_item][2]},quantity=${r.formValues[0]}..}] ~ ~ ~ 1.0 1.7 0.5`)
                                    player.runCommand(`scoreboard players add @s[hasitem={item=${kannkin_information_system2[player_Cash_Data[player.id].select_item][2]},quantity=${r.formValues[0]}..}] money ${kannkin_information_system2[player_Cash_Data[player.id].select_item][1]*r.formValues[0]}`)
                                    player.runCommand(`clear @s[hasitem={item=${kannkin_information_system2[player_Cash_Data[player.id].select_item][2]},quantity=${r.formValues[0]}..}] ${kannkin_information_system2[player_Cash_Data[player.id].select_item][2]} 0 ${r.formValues[0]}`)
                                }).catch(e => {
                                    console.error(e, e.stack);
                                });
                            }).catch(e => {
                                console.error(e, e.stack);
                            });
                    break;
                    case 9: 
                        const kounyuu_list = world.getDynamicProperty('kounyuu_list')
                        if(kounyuu_list==undefined){
                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(購入)§r] §a購入できるアイテムがありません"}]}`)
                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                            return;
                        }else{
                            var kounyuu_list_system1 = JSON.parse(kounyuu_list);
                        }
                        if(kounyuu_list_system1[0]==undefined){
                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(購入)§r] §a購入できるアイテムがありません"}]}`)
                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                            return;
                        }
                        //購入
                        var form = new ActionFormData();
                        form.title(`${config['main'][0]}`);
                        form.body("購入するアイテムを選択");
                        for (let i = 0; i < kounyuu_list_system1.length; i++){
                        form.button(`${kounyuu_list_system1[i][0]} 1個/§b${kounyuu_list_system1[i][1]}§r`,`textures/${kounyuu_list_system1[i][3]}`);
                        }
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            player_Cash_Data[player.id].select_item = r.selection;
                            var form = new ModalFormData();
                            form.textField("購入数(半角数字)", "0") 
                            form.show(player).then(r => {
                                if (r.canceled) return;
                                if (r.formValues[0]<0){
                                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(購入)§r] §40以下は設定できません"}]}`)
                                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                    return;
                                }
                                if (r.formValues[0]==''){
                                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(購入)§r] §4購入数を設定してください"}]}`)
                                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                    return;
                                }
                                const score = world.scoreboard.getObjective("money").getScore(player.scoreboardIdentity);
                                if(score>=kounyuu_list_system1[player_Cash_Data[player.id].select_item][1]*r.formValues[0]){
                                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(購入)§r] §e${r.formValues[0]}個 購入しました"}]}`)
                                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(購入)§r] §e${kounyuu_list_system1[player_Cash_Data[player.id].select_item][1]*r.formValues[0]}PAY支払いました"}]}`)
                                    player.runCommand(`give @s ${kounyuu_list_system1[player_Cash_Data[player.id].select_item][2]} ${r.formValues[0]}`)
                                    player.runCommand(`scoreboard players remove @s money ${kounyuu_list_system1[player_Cash_Data[player.id].select_item][1]*r.formValues[0]}`)
                                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                }else{
                                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(購入)§r] §4Moneyが足りません"}]}`)
                                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                }
                            })
                        })
                    break;
                    case 10: 
                    var form = new ActionFormData();
                        form.title(`${config['main'][0]}`);
                        form.body("情報サービスを選択");
                        form.button(`§l戻る`,'textures/ui/icon_import.png');
                        form.button("§1HARUAddons§5公式サイト\n§5<<<§0QRコードからアクセスできます",'textures/ui/qr.png');
                        form.button("§0Quick相場情報");
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0:
                                    //戻る
                                    HARUPhone1(eventData)
                                break;
                                case 1:
                                    var form = new ActionFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.body(`§bHARUPhoneニュース\n§e-------------\n§l§e開発者情報\n§r§a本アドオンをご利用くださいましてありがとうございます。§r\n開発者の§bHARUGAMEsです。\n§r今後も引き続きアップデート,修正していきます。\n\n§cリクエストなども受け付けております。\n詳しくは本アドオンDiscordサーバーにてご確認ください。`);
                                    form.button("閉じる");
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        let response = r.selection;
                                        switch (response) {
                                            case 0:
                                            break;
                                        }
                                    })
                                break;
                                case 2:
                                    var quick_information_system3 = []
                                    const quick_information = world.getDynamicProperty('quick_information')
                                    if(quick_information==undefined){
                                        var quick_information_system1=[]
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(情報)§r] §a情報が見つかりません"}]}`)
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                        return;
                                    }else{
                                        var quick_information_system1 = JSON.parse(quick_information);
                                    }
                                    for (let i = 0; i < quick_information_system1.length; i++){
                                        quick_information_system3=quick_information_system3+`§b${quick_information_system1[i][0]}§r:§e${quick_information_system1[i][1]}PAY\n`
                                    }
                                    var form = new ActionFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.body(`§dQuick相場表\n§e-------------\n${quick_information_system3}`);
                                    form.button("閉じる");
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        let response = r.selection;
                                        switch (response) {
                                            case 0:
                                            break;
                                        }
                                    })
                                break;
                            }
                        })
                    break; 
                    case 11:
                        var form = new ActionFormData();
                        form.title(`${config['main'][0]}`);
                        form.body("サービスを選択");
                        form.button(`§l戻る`,'textures/ui/icon_import.png');
                        form.button("§1ページ検索");
                        form.button("§5おすすめページ一覧");
                        form.button("§9ページ作成/編集/広告");
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0:
                                    //戻る
                                    HARUPhone1(eventData)
                                break;
                                case 1:
                                    var browser = world.getDynamicProperty('browser')
                                    if(browser==undefined){
                                        var browser_system2=[]
                                    }else{
                                    var browser_system2 = JSON.parse(browser);
                                    }
                                    var form = new ModalFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.textField("キーワードを入力", "キーワード検索")
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        var form = new ActionFormData();
                                        form.title(`${config['main'][0]}`);
                                        form.body("検索結果");
                                        var browser_cashdata1=[];
                                        for (let i = 0; i < browser_system2.length; i++){
                                            var domain_keyword_system1 = browser_system2[i][2].indexOf(`${r.formValues[0]}`);
                                            if(domain_keyword_system1 !== -1) {
                                                form.button(`§l${browser_system2[i][2]}\n投稿者:§r§5${browser_system2[i][0]}`);
                                                browser_cashdata1[browser_cashdata1.length]=i
                                            }
                                        }
                                        if(browser_cashdata1[0]==undefined){
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r] §aページが見つかりませんでした"}]}`)
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                        form.show(player).then(r => {
                                            if (r.canceled) return;
                                            let response = r.selection;
                                            browser_system2[browser_cashdata1[response]][1]=browser_system2[browser_cashdata1[response]][1]+1
                                            const browsersystem1 = JSON.stringify(browser_system2);
                                            world.setDynamicProperty('browser',browsersystem1)
                                            var form = new ActionFormData();
                                            form.title(`${config['main'][0]}`);
                                            form.body(`§l${browser_system2[browser_cashdata1[response]][3]}\n§e------------\n§r投稿者:§a${browser_system2[browser_cashdata1[response]][0]}\n§e§l------------\n§r${browser_system2[browser_cashdata1[response]][4]}\n\n${browser_system2[browser_cashdata1[response]][5]}\n\n${browser_system2[browser_cashdata1[response]][6]}\n\n${browser_system2[browser_cashdata1[response]][7]}`);
                                            form.button(`閉じる`);
                                            form.show(player).then(r => {
                                                if (r.canceled) return;
                                            })
                                        })
                                    })
                                break;
                                case 2:
                                    var browser = world.getDynamicProperty('browser')
                                    if(browser==undefined){
                                        var browser_system2=[]
                                    }else{
                                    var browser_system2 = JSON.parse(browser);
                                    }
                                    if(browser_system2[0]==undefined){
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r] §aページが見つかりませんでした"}]}`)
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                        return;
                                    }
                                    browser_system2.sort((a, b) => (a[1] > b[1] ? -1 : 1))
                                    var form = new ActionFormData();
                                        form.title(`${config['main'][0]}`);
                                        form.body("おすすめページ");
                                        for (let i = 0; i < browser_system2.length; i++){
                                                if(i<=7){
                                                form.button(`§l${browser_system2[i][2]}\n§r投稿者:§5${browser_system2[i][0]}`);
                                                }
                                        }
                                        form.show(player).then(r => {
                                            if (r.canceled) return;
                                            let response = r.selection;
                                            var form = new ActionFormData();
                                            form.title(`${config['main'][0]}`);
                                            form.body(`§l${browser_system2[response][3]}\n§e------------\n§r投稿者:§a${browser_system2[response][0]}\n§e§l------------\n§r${browser_system2[response][4]}\n\n${browser_system2[response][5]}\n\n${browser_system2[response][6]}\n\n${browser_system2[response][7]}`);
                                            form.button(`閉じる`);
                                            form.show(player).then(r => {
                                                if (r.canceled) return;
                                            })
                                        })
                                break;
                                case 3:
                                    var form = new ActionFormData();
                                        form.title(`${config['main'][0]}`);
                                        form.body("機能を選択");
                                        form.button(`§l新規作成 \n§rページ投稿費用:§b${world.getDynamicProperty('browser_newpage_money')}§rPAY`);
                                        form.button("§l既存のページ編集");
                                        form.button("§lページの削除");
                                        form.button(`§l広告\n§r§8こちらで作成したページを広告化できます`);
                                        form.show(player).then(r => {
                                            if (r.canceled) return;
                                            let response = r.selection;
                                            switch (response) {
                                                case 0:
                                                    if(world.getDynamicProperty('browser_newpage_money')==undefined){
                                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r §4管理者が初期設定を完了していない為新規作成出来ません"}]}`)
                                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                        return;
                                                    }
                                                    var form = new ModalFormData();
                                                    form.textField("検索表示タイトル", "ここは検索されやすいワード推奨") 
                                                    form.textField("ページタイトル", "ここは太字になります")
                                                    form.textField("文章1", "タイトルの下に追加されます")
                                                    form.textField("文章2", "文章1の下に追加されます")
                                                    form.textField("文章3", "文章2の下に追加されます")
                                                    form.textField("文章4", "文章3の下に追加されます")
                                                    form.show(player).then(r => {
                                                        if (r.canceled) return;
                                                        const score = world.scoreboard.getObjective("money").getScore(player.scoreboardIdentity);
                                                        if(score>=world.getDynamicProperty('browser_newpage_money')){
                                                        var browser = world.getDynamicProperty('browser')
                                                        if(browser==undefined){
                                                            var browser_system2=[]
                                                        }else{
                                                        var browser_system2 = JSON.parse(browser);
                                                        }
                                                        browser_system2.push([player.name,0,r.formValues[0],r.formValues[1],r.formValues[2],r.formValues[3],r.formValues[4],r.formValues[5]])
                                                        const browser_system3 = JSON.stringify(browser_system2);
                                                        world.setDynamicProperty('browser',browser_system3)
                                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r §e${world.getDynamicProperty('browser_newpage_money')}PAY支払いました"}]}`)
                                                            player.runCommand(`scoreboard players remove @s money ${world.getDynamicProperty('browser_newpage_money')}`)
                                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r] §a新規作成しました"}]}`)
                                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                        }else{
                                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r] §4Moneyが足りません"}]}`)
                                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                        }
                                                    })
                                                break;
                                                case 1:
                                                    var browser = world.getDynamicProperty('browser')
                                                        if(browser==undefined){
                                                            var browser_system2=[]
                                                        }else{
                                                        var browser_system2 = JSON.parse(browser);
                                                        }
                                                        var browser_cash = [];
                                                        for (let i = 0; i < browser_system2.length; i++){
                                                            if(browser_system2[i][0]==player.name){
                                                                browser_cash.push([[i],browser_system2[i]])
                                                            }
                                                        }
                                                        if(browser_cash[0]==undefined){
                                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r] §a編集できるページがありません"}]}`)
                                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                            return;
                                                        }
                                                    var form = new ActionFormData();
                                                    form.title(`${config['main'][0]}`);
                                                    form.body("編集するページを選択");
                                                    for (let i = 0; i < browser_cash.length; i++){
                                                        form.button(`§l${browser_cash[i][1][2]}\n§r${browser_cash[i][1][3]}`);
                                                    }
                                                    form.show(player).then(r => {
                                                        if (r.canceled) return;
                                                        let response = r.selection;
                                                        var form = new ModalFormData();
                                                        form.textField("検索表示タイトル", `${browser_cash[response][1][2]}`) 
                                                        form.textField("ページタイトル", `${browser_cash[response][1][3]}`)
                                                        form.textField("文章1", `${browser_cash[response][1][4]}`)
                                                        form.textField("文章2", `${browser_cash[response][1][5]}`)
                                                        form.textField("文章3", `${browser_cash[response][1][6]}`)
                                                        form.textField("文章4", `${browser_cash[response][1][7]}`)
                                                        form.show(player).then(r => {
                                                            if (r.canceled) return;
                                                            if(r.formValues[0]!=''){browser_cash[response][1][2]=r.formValues[0]}
                                                            if(r.formValues[1]!=''){browser_cash[response][1][3]=r.formValues[1]}
                                                            if(r.formValues[2]!=''){browser_cash[response][1][4]=r.formValues[2]}
                                                            if(r.formValues[3]!=''){browser_cash[response][1][5]=r.formValues[3]}
                                                            if(r.formValues[4]!=''){browser_cash[response][1][6]=r.formValues[4]}
                                                            if(r.formValues[5]!=''){browser_cash[response][1][7]=r.formValues[5]}
                                                            browser_system2[browser_cash[response][0][0]]=browser_cash[response][1]
                                                            const browser_system3 = JSON.stringify(browser_system2);
                                                            world.setDynamicProperty('browser',browser_system3)
                                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r] §aページを編集しました"}]}`)
                                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                        })
                                                    })
                                                break;
                                                case 2:
                                                    var browser = world.getDynamicProperty('browser')
                                                        if(browser==undefined){
                                                            var browser_system2=[]
                                                        }else{
                                                        var browser_system2 = JSON.parse(browser);
                                                        }
                                                        var browser_cash = [];
                                                        for (let i = 0; i < browser_system2.length; i++){
                                                            if(browser_system2[i][0]==player.name){
                                                                browser_cash.push([[i],browser_system2[i]])
                                                            }
                                                        }
                                                        if(browser_cash[0]==undefined){
                                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r] §a削除できるページがありません"}]}`)
                                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                            return;
                                                        }
                                                    var form = new ActionFormData();
                                                    form.title(`${config['main'][0]}`);
                                                    form.body("削除するページを選択");
                                                    for (let i = 0; i < browser_cash.length; i++){
                                                        form.button(`§l${browser_cash[i][1][2]}\n§r${browser_cash[i][1][3]}`);
                                                    }
                                                    form.show(player).then(r => {
                                                        if (r.canceled) return;
                                                        let response = r.selection;
                                                        browser_system2.splice( browser_cash[response][0][0] , 1 );
                                                        const browser_system3 = JSON.stringify(browser_system2);
                                                        world.setDynamicProperty('browser',browser_system3)
                                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r] §aページを削除しました"}]}`)
                                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                    })
                                                break;
                                                case 3:
                                                    var form = new ActionFormData();
                                                    form.title(`${config['main'][0]}`);
                                                    form.body("サービスを選択");
                                                    form.button(`§l広告化 \n§rページ広告化費用:§b${world.getDynamicProperty('browser_performance_money')}§rPAY`);
                                                    form.button("§l広告削除");
                                                    form.show(player).then(r => {
                                                        if (r.canceled) return;
                                                        let response = r.selection;
                                                        switch (response) {
                                                            case 0:
                                                                if(world.getDynamicProperty('browser_performance_money')==undefined){
                                                                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r] §4管理者が初期設定を完了していない為新規作成出来ません"}]}`)
                                                                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                                    return;
                                                                }
                                                                var browser = world.getDynamicProperty('browser')
                                                                    if(browser==undefined){
                                                                        var browser_system2=[]
                                                                    }else{
                                                                    var browser_system2 = JSON.parse(browser);
                                                                    }
                                                                    var browser_cash = [];
                                                                    for (let i = 0; i < browser_system2.length; i++){
                                                                        if(browser_system2[i][0]==player.name){
                                                                            browser_cash.push([[i],browser_system2[i]])
                                                                        }
                                                                    }
                                                                    if(browser_cash[0]==undefined){
                                                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r] §a広告化できるページがありません"}]}`)
                                                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                                        return;
                                                                    }
                                                                var form = new ActionFormData();
                                                                form.title(`${config['main'][0]}`);
                                                                form.body("広告化するページを選択");
                                                                for (let i = 0; i < browser_cash.length; i++){
                                                                    form.button(`§l${browser_cash[i][1][2]}\n§r${browser_cash[i][1][3]}`);
                                                                }
                                                                form.show(player).then(r => {
                                                                    if (r.canceled) return;
                                                                    let response = r.selection;
                                                                    const score = world.scoreboard.getObjective("money").getScore(player.scoreboardIdentity);
                                                                    if(score>=world.getDynamicProperty('browser_performance_money')){
                                                                    var performance = world.getDynamicProperty('performance')
                                                                    if(performance==undefined){
                                                                        var performance_system2=[]
                                                                    }else{
                                                                    var performance_system2 = JSON.parse(performance);
                                                                    }   
                                                                    var performance_cash_system2 = 0;
                                                                    for (let i = 0; i < performance_system2.length; i++){
                                                                        if(performance_system2[i][2]==browser_cash[response][1][2]&&performance_system2[i][0]==browser_cash[response][1][0]&&performance_system2[i][3]==browser_cash[response][1][3]&&performance_system2[i][4]==browser_cash[response][1][4]&&performance_system2[i][5]==browser_cash[response][1][5]){
                                                                            performance_cash_system2 = 1
                                                                        }
                                                                    }
                                                                        if(performance_cash_system2 == 1){
                                                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r] §4選択したページは既に広告化済みです"}]}`)
                                                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                                            return;
                                                                        }
                                                                        performance_system2.push(browser_cash[response][1])
                                                                        const performance_system3 = JSON.stringify(performance_system2);
                                                                        world.setDynamicProperty('performance',performance_system3)
                                                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r] §e${world.getDynamicProperty('browser_performance_money')}PAY支払いました"}]}`)
                                                                        player.runCommand(`scoreboard players remove @s money ${world.getDynamicProperty('browser_performance_money')}`)
                                                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r] §aページを広告化しました"}]}`)
                                                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                                }else{
                                                                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r] §4Moneyが足りません"}]}`)
                                                                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                                }
                                                            })
                                                           break;
                                                           case 1:
                                                            var browser = world.getDynamicProperty('performance')
                                                            if(browser==undefined){
                                                                var browser_system2=[]
                                                            }else{
                                                            var browser_system2 = JSON.parse(browser);
                                                            }
                                                            var browser_cash = [];
                                                            for (let i = 0; i < browser_system2.length; i++){
                                                                if(browser_system2[i][0]==player.name){
                                                                    browser_cash.push([[i],browser_system2[i]])
                                                                }
                                                            }
                                                            if(browser_cash[0]==undefined){
                                                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r] §a削除できる広告がありません"}]}`)
                                                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                                return;
                                                            }
                                                        var form = new ActionFormData();
                                                        form.title(`${config['main'][0]}`);
                                                        form.body("削除する広告を選択");
                                                        for (let i = 0; i < browser_cash.length; i++){
                                                            form.button(`§l${browser_cash[i][1][2]}\n§r${browser_cash[i][1][3]}`);
                                                        }
                                                        form.show(player).then(r => {
                                                            if (r.canceled) return;
                                                            let response = r.selection;
                                                            browser_system2.splice( browser_cash[response][0][0] , 1 );
                                                            const browser_system3 = JSON.stringify(browser_system2);
                                                            world.setDynamicProperty('performance',browser_system3)
                                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r] §a広告を削除しました"}]}`)
                                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                        })
                                                           break;
                                                        }
                                                    })
                                                    
                                                    
                                                break;
                                            }
                                        })
                                        
                                break;
                            }
                        })
                    break;
                    case 12:
                        var short_data_cash1 = [[],[]];
                        var short_data = world.getDynamicProperty('short_data')
                        if(short_data==undefined){
                            var short_data_system2=[]
                        }else{
                        var short_data_system2 = JSON.parse(short_data);
                        }
                        var form = new ActionFormData();
                        form.title(`${config['main'][0]}`);
                        form.body("サービスを選択");
                        form.button(`§l戻る`,'textures/ui/icon_import.png');
                        form.button("§1パーティーを作成");
                        form.button("§5招待を確認");
                        for (let i = 0; i < short_data_system2.length; i++){
                            for (let i1 = 0; i1 < short_data_system2[i][1].length; i1++){
                            if(short_data_system2[i][1][i1]==player.name&&short_data_system2[i][2][i1]==1){
                                form.button(`§l${short_data_system2[i][0]}`);
                                short_data_cash1[0].push(i)
                            }
                            }
                        }
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response1 = r.selection;
                            switch (response1) {
                                case 0:
                                        //戻る
                                        HARUPhone1(eventData)
                                break;
                                case 1:
                                    var short_data = world.getDynamicProperty('short_data')
                                    if(short_data==undefined){
                                        var short_data_system2=[]
                                    }else{
                                    var short_data_system2 = JSON.parse(short_data);
                                    }
                                    var form = new ModalFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.textField("パーティー名", ``) 
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        short_data_system2.push([r.formValues[0],[player.name],[1],[]])
                                        const short_data_system3 = JSON.stringify(short_data_system2);
                                        world.setDynamicProperty('short_data',short_data_system3)
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(short)§r] §aパーティーを作成しました"}]}`) 
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                    })
                                break;
                                case 2:
                                    var short_data_cash2 = [[],[],0]
                                    var short_data = world.getDynamicProperty('short_data')
                                    if(short_data==undefined){
                                        var short_data_system2=[]
                                    }else{
                                    var short_data_system2 = JSON.parse(short_data);
                                    }
                                    var form = new ActionFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.body("参加するパーティーを選択");
                                    for (let i = 0; i < short_data_system2.length; i++){
                                        for (let i1 = 0; i1 < short_data_system2[i][1].length; i1++){
                                            if(short_data_system2[i][1][i1]==player.name&&short_data_system2[i][2][i1]==0){
                                                form.button(`${short_data_system2[i][0]}`);
                                                short_data_cash2[0].push(i)
                                                short_data_cash2[1].push(i1)
                                                short_data_cash2[2]=1
                                            }
                                        }
                                    }
                                    if(short_data_cash2[2]==0){
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(short)§r] §a招待がありません"}]}`) 
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                        return;
                                    }
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        let response = r.selection;
                                        short_data_system2[short_data_cash2[0][response]][2][short_data_cash2[1][response]]=1
                                        const short_data_system3 = JSON.stringify(short_data_system2);
                                        world.setDynamicProperty('short_data',short_data_system3)
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(short)§r] §aパーティーに参加しました"}]}`) 
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                    })
                                break;
                            }
                            if(response1!=0&&response1!=1&&response1!=2){
                                var short_data = world.getDynamicProperty('short_data')
                                if(short_data==undefined){
                                    var short_data_system2=[]
                                }else{
                                var short_data_system2 = JSON.parse(short_data);
                                }
                            short_data_cash1[1].push(response1-3)
                            var form = new ActionFormData();
                            form.title(`${config['main'][0]}`);
                            form.body("サービスを選択");
                            form.button("メッセージを表示");
                            form.button("メッセージを送信");
                            form.button("メンバーリスト");
                            form.button("パーティー設定");
                            form.show(player).then(r => {
                                if (r.canceled) return;
                                let response = r.selection;
                                switch (response) {
                                    case 0:
                                        var short_data = world.getDynamicProperty('short_data')
                                        if(short_data==undefined){
                                            var short_data_system2=[]
                                        }else{
                                        var short_data_system2 = JSON.parse(short_data);
                                        }
                                        var short_data_text = ''
                                        for (let i = 0; i < short_data_system2[short_data_cash1[0][short_data_cash1[1][0]]][3].length; i++){
                                         short_data_text = short_data_text+`§a${short_data_system2[short_data_cash1[0][short_data_cash1[1][0]]][3][i][1]}\n§r ${short_data_system2[short_data_cash1[0][short_data_cash1[1][0]]][3][i][0]}\n\n`
                                        }
                                        var form = new ActionFormData();
                                        form.title(`${config['main'][0]}`);
                                        form.body(`${short_data_text}`);
                                        form.button("メッセージを送信");
                                        form.show(player).then(r => {
                                            if (r.canceled) return;
                                            let response = r.selection;
                                            switch (response) {
                                                case 0:
                                                    var form = new ModalFormData();
                                                    form.title(`${config['main'][0]}`);
                                                    form.textField("メッセージを入力", ``) 
                                                    form.show(player).then(r => {
                                                        if (r.canceled) return;
                                                        short_data_system2[short_data_cash1[0][short_data_cash1[1][0]]][3].push([r.formValues[0],player.name])
                                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(short)§r] §aメッセージを送信しました"}]}`) 
                                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                        const short_data_system3 = JSON.stringify(short_data_system2);
                                                        world.setDynamicProperty('short_data',short_data_system3)
                                                    })
                                                break;
                                            }
                                        })
                                    break;
                                    case 1:
                                        var short_data = world.getDynamicProperty('short_data')
                                        if(short_data==undefined){
                                            var short_data_system2=[]
                                        }else{
                                        var short_data_system2 = JSON.parse(short_data);
                                        }
                                        var form = new ModalFormData();
                                        form.title(`${config['main'][0]}`);
                                        form.textField("メッセージを入力", ``) 
                                        form.show(player).then(r => {
                                            if (r.canceled) return;
                                            short_data_system2[short_data_cash1[0][short_data_cash1[1][0]]][3].push([r.formValues[0],player.name])
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(short)§r] §aメッセージを送信しました"}]}`) 
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                            const short_data_system3 = JSON.stringify(short_data_system2);
                                            world.setDynamicProperty('short_data',short_data_system3)
                                        })
                                    break;
                                    case 2:
                                        var short_data = world.getDynamicProperty('short_data')
                                        if(short_data==undefined){
                                            var short_data_system2=[]
                                        }else{
                                        var short_data_system2 = JSON.parse(short_data);
                                        }
                                        var short_data_memberList = ''
                                            for (let i = 0; i < short_data_system2[short_data_cash1[0][short_data_cash1[1][0]]][1].length; i++){
                                                if(short_data_system2[short_data_cash1[0][short_data_cash1[1][0]]][2][i]==1){
                                                short_data_memberList = short_data_memberList+`§a・${short_data_system2[short_data_cash1[0][short_data_cash1[1][0]]][1][i]}\n`
                                                }
                                            }
                                            var form = new ActionFormData();
                                            form.title(`${config['main'][0]}`);
                                            form.body(`メンバーリスト\n\n${short_data_memberList}`);
                                            form.button("閉じる");
                                            form.show(player).then(r => {
                                                if (r.canceled) return;
                                                let response = r.selection;
                                                switch (response) {
                                                    case 0:
                                                    break;
                                                }
                                            })   
                                    break;
                                    case 3:
                                        var short_data = world.getDynamicProperty('short_data')
                                        if(short_data==undefined){
                                            var short_data_system2=[]
                                        }else{
                                        var short_data_system2 = JSON.parse(short_data);
                                        }
                                        if(short_data_system2[short_data_cash1[0][short_data_cash1[1][0]]][1][0]!=player.name){
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(short)§r] §4パーティー作成者のみ設定を行えます"}]}`) 
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                        var form = new ActionFormData();
                                        form.title(`${config['main'][0]}`);
                                        form.body("サービスを選択");
                                        form.button("§5メンバーを招待する");
                                        form.button("§1メッセージ履歴の削除/整理");
                                        form.button("§4パーティーの削除");
                                        form.show(player).then(r => {
                                            if (r.canceled) return;
                                            let response = r.selection;
                                            switch (response) {
                                                case 0:
                                                    var form = new ActionFormData();
                                                    form.title(`${config['main'][0]}`);
                                                    form.body("サービスを選択");
                                                    form.button("オンラインのプレイヤーから指定する");
                                                    form.button("ゲーマータグを入力して指定する");
                                                    form.show(player).then(r => {
                                                        if (r.canceled) return;
                                                        let response = r.selection;
                                                        switch (response) {
                                                            case 0:
                                                                var short_data = world.getDynamicProperty('short_data')
                                                                if(short_data==undefined){
                                                                    var short_data_system2=[]
                                                                }else{
                                                                var short_data_system2 = JSON.parse(short_data);
                                                                }
                                                                var players = world.getAllPlayers()
                                                                var form = new ActionFormData();
                                                                form.title(`${config['main'][0]}`);
                                                                form.body("招待するプレイヤーを選択");
                                                                for (let i = 0; i < players.length; i++){
                                                                    form.button(`${players[i].name}`);
                                                                }
                                                                form.show(player).then(r => {
                                                                    if (r.canceled) return;
                                                                    let response = r.selection;
                                                                    var short_data_cash3 = 0
                                                                    for (let i = 0; i < short_data_system2[short_data_cash1[0][short_data_cash1[1][0]]][1].length; i++){
                                                                        if(short_data_system2[short_data_cash1[0][short_data_cash1[1][0]]][1][i]==players[response].name){
                                                                            short_data_cash3 = 1
                                                                            if(short_data_system2[short_data_cash1[0][short_data_cash1[1][0]]][2][i]==0){
                                                                                short_data_cash3 = 2
                                                                            }
                                                                        }
                                                                    }
                                                                    if(short_data_cash3==1){
                                                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(short)§r] §4指定したプレイヤーは既にパーティーに参加しています"}]}`) 
                                                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                                        return;
                                                                    }
                                                                    if(short_data_cash3==2){
                                                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(short)§r] §4指定したプレイヤーは既に招待しています"}]}`) 
                                                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                                        return;
                                                                    }
                                                                    short_data_system2[short_data_cash1[0][short_data_cash1[1][0]]][1].push(players[response].name)
                                                                    short_data_system2[short_data_cash1[0][short_data_cash1[1][0]]][2].push(0)
                                                                    const short_data_system3 = JSON.stringify(short_data_system2);
                                                                    world.setDynamicProperty('short_data',short_data_system3)
                                                                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(short)§r] §a${players[response].name}を招待しました"}]}`) 
                                                                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                                })
                                                            break;
                                                            case 1:
                                                                var short_data = world.getDynamicProperty('short_data')
                                                                if(short_data==undefined){
                                                                    var short_data_system2=[]
                                                                }else{
                                                                var short_data_system2 = JSON.parse(short_data);
                                                                }
                                                                var form = new ModalFormData();
                                                                form.title(`${config['main'][0]}`);
                                                                form.textField("招待するゲーマータグ", ``) 
                                                                form.show(player).then(r => {
                                                                    if (r.canceled) return;
                                                                    var short_data_cash3 = 0
                                                                    for (let i = 0; i < short_data_system2[short_data_cash1[0][short_data_cash1[1][0]]][1].length; i++){
                                                                        if(short_data_system2[short_data_cash1[0][short_data_cash1[1][0]]][1][i]==r.formValues[0]){
                                                                            short_data_cash3 = 1
                                                                            if(short_data_system2[short_data_cash1[0][short_data_cash1[1][0]]][2][i]==0){
                                                                                short_data_cash3 = 2
                                                                            }
                                                                        }
                                                                    }
                                                                    if(short_data_cash3==1){
                                                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(short)§r] §4指定したプレイヤーは既にパーティーに参加しています"}]}`) 
                                                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                                        return;
                                                                    }
                                                                    if(short_data_cash3==2){
                                                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(short)§r] §4指定したプレイヤーは既に招待しています"}]}`) 
                                                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                                        return;
                                                                    }
                                                                    short_data_system2[short_data_cash1[0][short_data_cash1[1][0]]][1].push(r.formValues[0])
                                                                    short_data_system2[short_data_cash1[0][short_data_cash1[1][0]]][2].push(0)
                                                                    const short_data_system3 = JSON.stringify(short_data_system2);
                                                                    world.setDynamicProperty('short_data',short_data_system3)
                                                                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(short)§r] §a${r.formValues[0]}を招待しました"}]}`) 
                                                                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                                })
                                                            break;
                                                        }
                                                    })

                                                break;
                                                case 1:
                                                    var form = new ActionFormData();
                                                    form.title(`${config['main'][0]}`);
                                                    form.body("機能を選択")
                                                    form.button("すべてメッセージを削除する");
                                                    form.button("範囲を指定してメッセージを削除する");
                                                    form.show(player).then(r => {
                                                        if (r.canceled) return;
                                                        let response = r.selection;
                                                        switch (response) {
                                                            case 0:
                                                                var short_data = world.getDynamicProperty('short_data')
                                                                if(short_data==undefined){
                                                                    var short_data_system2=[]
                                                                }else{
                                                                var short_data_system2 = JSON.parse(short_data);
                                                                }
                                                                var form = new ActionFormData();
                                                                form.title(`${config['main'][0]}`);
                                                                form.body("本当に削除しますか?")
                                                                form.button("削除する");
                                                                form.button("キャンセル");
                                                                form.show(player).then(r => {
                                                                    if (r.canceled) return;
                                                                    let response = r.selection;
                                                                    switch (response) {
                                                                        case 0:
                                                                            short_data_system2[short_data_cash1[0][short_data_cash1[1][0]]][3]=[]
                                                                            const short_data_system3 = JSON.stringify(short_data_system2);
                                                                            world.setDynamicProperty('short_data',short_data_system3)
                                                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(short)§r] §aメッセージを削除しました"}]}`) 
                                                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                                        break;
                                                                    }
                                                                })
                                                            break;
                                                            case 1:
                                                                var short_data = world.getDynamicProperty('short_data')
                                                                if(short_data==undefined){
                                                                    var short_data_system2=[]
                                                                }else{
                                                                var short_data_system2 = JSON.parse(short_data);
                                                                }
                                                                var form = new ModalFormData();
                                                                form.title(`${config['main'][0]}`);
                                                                form.textField("削除点[半角数字]", `0`) 
                                                                form.textField("削除数[半角数字]", ``) 
                                                                form.show(player).then(r => {
                                                                    if (r.canceled) return;
                                                                    short_data_system2[short_data_cash1[0][short_data_cash1[1][0]]][3].splice(r.formValues[0],r.formValues[1])
                                                                    const short_data_system3 = JSON.stringify(short_data_system2);
                                                                    world.setDynamicProperty('short_data',short_data_system3)
                                                                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(short)§r] §b${r.formValues[0]}§aを基準に§b${r.formValues[1]}§a個メッセージを削除しました"}]}`) 
                                                                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                                })
                                                            break;
                                                        }
                                                    })
                                                break;
                                                case 2:
                                                    var short_data = world.getDynamicProperty('short_data')
                                                    if(short_data==undefined){
                                                        var short_data_system2=[]
                                                    }else{
                                                    var short_data_system2 = JSON.parse(short_data);
                                                    }
                                                    var form = new ActionFormData();
                                                    form.title(`${config['main'][0]}`);
                                                    form.body("本当に削除しますか?")
                                                    form.button("削除する");
                                                    form.button("キャンセル");
                                                    form.show(player).then(r => {
                                                        if (r.canceled) return;
                                                        let response = r.selection;
                                                        switch (response) {
                                                            case 0:
                                                                short_data_system2.splice(short_data_cash1[0][short_data_cash1[1][0]],1)
                                                                const short_data_system3 = JSON.stringify(short_data_system2);
                                                                world.setDynamicProperty('short_data',short_data_system3)
                                                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(short)§r] §aパーティーを削除しました"}]}`) 
                                                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                            break;
                                                        }
                                                    })
                                                break;
                                            }
                                        })
                                    break;
                                }
                            })
                        }
                        })
                    break;
                    case 13:
                        var form = new ActionFormData();
                        form.title(`${config['main'][0]}`);
                        form.body("設定を選択");
                        form.button(`§l戻る`,'textures/ui/icon_import.png');
                        form.button("§9請求を送る");
                        form.button("§5届いた請求を確認");
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0:
                                    //戻る
                                    HARUPhone1(eventData)
                                break;
                                case 1:
                                    player_Cash_Data[player.id] = {}
                                    player_Cash_Data[player.id].players = world.getAllPlayers()
                                    var form = new ActionFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.body("請求送信先プレイヤーを選択");
                                    for (let i = 0; i < player_Cash_Data[player.id].players.length; i++){
                                        form.button(`${player_Cash_Data[player.id].players[i].name}`);
                                    }
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        player_Cash_Data[player.id].select_player = player_Cash_Data[player.id].players[r.selection];
                                        var form = new ModalFormData();
                                        form.title(`${config['main'][0]}`);
                                        form.textField("請求金額", ``) 
                                        form.textField("請求理由", ``) 
                                        form.show(player).then(r => {
                                            if (r.canceled) return;
                                            if(isNaN(r.formValues[0])){
                                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(HARUPAY)§r] §4半角数字で入力してください"}]}`)
                                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                return;
                                            }
                                            if (r.formValues[0]<0){
                                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(HARUPAY)§r] §40以下は設定できません"}]}`)
                                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                return;
                                            }
                                            if(Claim[player_Cash_Data[player.id].select_player.name]==undefined){
                                               Claim[player_Cash_Data[player.id].select_player.name] = []
                                            }
                                            Claim[player_Cash_Data[player.id].select_player.name].push([player.name,Number(r.formValues[0]),r.formValues[1]])
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(請求)§r] §a${player_Cash_Data[player.id].select_player.name}§rへ請求を送信しました"}]}`) 
                                            player_Cash_Data[player.id].select_player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(請求)§r] §a${player.name}§rから§2${r.formValues[1]}§rの請求が届きました"}]}`) 
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.5 0.5`)
                                            player_Cash_Data[player.id].select_player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.5 0.5`)
                                        })
                                    })
                                break;
                                case 2:
                                    if(Claim[player.name]==undefined){
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(請求)§r] §a届いた請求が見つかりません"}]}`) 
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.5`)
                                        return;
                                    }
                                    player_Cash_Data[player.id] = {}
                                    var form = new ActionFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.body("処理を行う請求をお選びください");
                                    for (let i = 0; i < Claim[player.name].length; i++){
                                        form.button(`§9${Claim[player.name][i][2]}\n§0送信したプレイヤー:§s${Claim[player.name][i][0]}`);
                                    }
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        player_Cash_Data[player.id].select = r.selection;
                                        var form = new ActionFormData();
                                        form.title(`${config['main'][0]}`);
                                        form.body(`§l請求の詳細\n§r請求理由:§a${Claim[player.name][player_Cash_Data[player.id].select][2]}\n§r請求金額:§a${Claim[player.name][player_Cash_Data[player.id].select][1]}\n§r請求を送信したプレイヤー:§a${Claim[player.name][player_Cash_Data[player.id].select][0]}`);
                                        form.button("§1許可");
                                        form.button("§5拒否");
                                        form.show(player).then(r => {
                                            if (r.canceled) return;
                                            let response = r.selection;
                                            switch (response) {
                                                case 0:
                                                  player_Cash_Data[player.id].claim_stop = false
                                                  player_Cash_Data[player.id].players = world.getAllPlayers()
                                                  for (let i = 0; i < player_Cash_Data[player.id].players.length; i++){
                                                    if(Claim[player.name][player_Cash_Data[player.id].select][0] === player_Cash_Data[player.id].players[i].name){
                                                        player_Cash_Data[player.id].claim_stop = true
                                                    }
                                                  }
                                                  if(player_Cash_Data[player.id].claim_stop == false){
                                                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(請求)§r] §4相手プレイヤーがオフラインの為処理を中止しました"}]}`) 
                                                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.5`)
                                                    return;
                                                  }
                                                  const score = world.scoreboard.getObjective("money").getScore(player.scoreboardIdentity);
                                                 //残高が設定金額以上の場合のみ実行
                                                  if(score >= Claim[player.name][player_Cash_Data[player.id].select][1]){
                                                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(請求)§r] §a請求を許可しました §e${Claim[player.name][player_Cash_Data[player.id].select][1]}PAY送信しました"}]}`) 
                                                    player.runCommand(`tellraw @a[name="${Claim[player.name][player_Cash_Data[player.id].select][0]}"] {"rawtext":[{"text":"§r[§a通知§7(請求)§r] §a${player.name}が${Claim[player.name][player_Cash_Data[player.id].select][2]}の請求を許可しました §e${Claim[player.name][player_Cash_Data[player.id].select][1]}PAY受け取りました"}]}`)
                                                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.5 0.5`)
                                                    player.runCommand(`playsound random.toast @a[name="${Claim[player.name][player_Cash_Data[player.id].select][0]}"] ~ ~ ~ 1.0 1.5 0.5`)
                                                    player.runCommand(`scoreboard players add @a[name="${Claim[player.name][player_Cash_Data[player.id].select][0]}"] money ${Claim[player.name][player_Cash_Data[player.id].select][1]}`)   
                                                    player.runCommand(`scoreboard players remove @a[name="${player.name}", scores={money=${Claim[player.name][player_Cash_Data[player.id].select][1]}..}] money ${Claim[player.name][player_Cash_Data[player.id].select][1]}`)
                                                    Claim[player.name].splice( player_Cash_Data[player.id].select, 1 )
                                                 }
                                                break;
                                                case 1:
                                                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(請求)§r] §a請求を§4拒否しました"}]}`) 
                                                    player.runCommand(`tellraw @a[name="${Claim[player.name][player_Cash_Data[player.id].select][0]}"] {"rawtext":[{"text":"§r[§a通知§7(請求)§r] §a${player.name}が${Claim[player.name][player_Cash_Data[player.id].select][2]}の請求を§4拒否しました"}]}`)
                                                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.5 0.5`)
                                                    player.runCommand(`playsound random.toast @a[name="${Claim[player.name][player_Cash_Data[player.id].select][0]}"] ~ ~ ~ 1.0 1.5 0.5`)
                                                    Claim[player.name].splice( player_Cash_Data[player.id].select, 1 )
                                                break;
                                            }
                                        })
                                    }) 
                                break;
                            }
                        })
                        Claim
                    break;
                    case 14:
                        var form = new ActionFormData();
                        form.title(`${config['main'][0]}`);
                        form.body(`§aチャットボットを選択`);
                        form.button("§1Insight-2");
                        form.button("§1Insight-3");
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0:
                                    chatLoop2(player, eventData);
                                break;
                                case 1:
                                    chatLoop3(player, eventData);
                                break;
                            }
                        })

                    break;
                    case 15:
                         //管理者専門画面
                         var form = new ActionFormData();
                         form.title(`${config['main'][0]}`);
                         form.body(`§5Operator Controller\n§a管理者HARUPAY残高§r:§e${world.getDynamicProperty('harupay_op_money')}\n§e--------------\n`);
                         form.button("§1ログ");
                         form.button("§5データ編集");
                         form.button("§2データ権限削除");
                         form.button("§4トラブルシューティング");
                         form.button("§1機能利用金額のカスタマイズ");
                         form.button("§3その他");
                         form.button("§9管理者版HARUPAY");
                         form.show(player).then(r => {
                             if (r.canceled) return;
                             let response = r.selection;
                             switch (response) {
                                 case 0:
                                     var form = new ActionFormData();
                                     form.title(`${config['main'][0]}`);
                                     form.body("§5ログを選択");
                                     form.button("§9HARUPAY");
                                     form.button("§1Quick");
                                     form.button("§2仕事依頼");
                                     form.button("§5換金/購入");
                                     form.show(player).then(r => {
                                         if (r.canceled) return;
                                         let response = r.selection;
                                         switch (response) {
                                             case 0:
                                                 var  logs_list = '';
                                                 for (let i = 0; i < logs['harupay'].length; i++){
                                                    logs_list = logs_list+`§s${logs['harupay'][i][0]} §a${logs['harupay'][i][1]}§rから§a${logs['harupay'][i][2]}§rへ§e${logs['harupay'][i][3]}§r送信\n`
                                                 }
                                                 
                                                 var form = new ActionFormData();
                                                 form.title(`${config['main'][0]}`);
                                                 form.body(`HARUPAYlog\n${logs_list}`);
                                                 form.button("§0閉じる");
                                                 form.show(player).then(r => {
                                                     if (r.canceled) return;
                                                     let response = r.selection;
                                                     switch (response) {
                                                         case 0:
                                                         break;
                                                     }
                                                 })
                                             break;
                                             case 1:
                                                var  logs_list = '';
                                                 for (let i = 0; i < logs['quick'].length; i++){
                                                    logs_list = logs_list+`§s${logs['quick'][i][0]} §a${logs['quick'][i][1]}§rから§a${logs['quick'][i][2]}§rへ§e${logs['quick'][i][3]}§r送信\n`
                                                 }
                                                 var form = new ActionFormData();
                                                 form.title(`${config['main'][0]}`);
                                                 form.body(`Quick Log\n${logs_list}`);
                                                 form.button("§0閉じる");
                                                 form.show(player).then(r => {
                                                     if (r.canceled) return;
                                                     let response = r.selection;
                                                     switch (response) {
                                                         case 0:
                                                         break;
                                                     }
                                                 })
                                             break
                                             case 2:
                                                var  logs_list = '';
                                                 for (let i = 0; i < logs['quest'].length; i++){
                                                    logs_list = logs_list+`§s${logs['quest'][i][0]} §a${logs['quest'][i][1]}§rが§a${logs['quest'][i][3]}§rを受けた §a募集者§r:§e${logs['quest'][i][2]}\n`
                                                 }
                                                 var form = new ActionFormData();
                                                 form.title(`${config['main'][0]}`);
                                                 form.body(`仕事依頼 Log\n${logs_list}`);
                                                 form.button("§0閉じる");
                                                 form.show(player).then(r => {
                                                     if (r.canceled) return;
                                                     let response = r.selection;
                                                     switch (response) {
                                                         case 0:
                                                         break;
                                                     }
                                                 })
                                             break;
                                             case 3:
                                                 var form = new ActionFormData();
                                                 form.title(`${config['main'][0]}`);
                                                 form.body("情報を選択");
                                                 form.button("§5換金ログ");
                                                 form.button("§9購入ログ");
                                                 form.show(player).then(r => {
                                                     if (r.canceled) return;
                                                     let response = r.selection;
                                                     switch (response) {
                                                         case 0:
                                                             var kannkin_log = world.getDynamicProperty('kannkin_log')
                                                             if(kannkin_log==undefined){
                                                                 var kannkin_log_system2=[]
                                                             }else{
                                                             var kannkin_log_system2 = JSON.parse(kannkin_log);
                                                             }
                                                             if(kannkin_log_system2[0]==undefined){
                                                                 player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(購入)§r] §a換金取引ログがありません"}]}`)
                                                                 player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                                 return;
                                                             }
                                                             var kannkin_information = world.getDynamicProperty('kannkin_information')
                                                             if(kannkin_information==undefined){
                                                                 var kannkin_information_system2=[]
                                                             }else{
                                                             var kannkin_information_system2 = JSON.parse(kannkin_information);
                                                             }
                                                             if(kannkin_information_system2[0]==undefined){
                                                                 player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(換金)§r] §a換金できるアイテムがありません"}]}`)
                                                                 player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                                 return;
                                                             }
                                                             var form = new ActionFormData();
                                                             form.title(`${config['main'][0]}`);
                                                             form.body(`§5換金ログ\n§e-----------\n§b[ログ]`);
                                                             for (let i = 0; i < kannkin_information_system2.length; i++){
                                                                 form.button(`${kannkin_information_system2[i][0]} 1個/§b${kannkin_information_system2[i][1]}§r`,`textures/${kannkin_information_system2[i][3]}`);
                                                             }
                                                             form.show(player).then(r => {
                                                                 if (r.canceled) return;
                                                                 let response = r.selection;
                                                                 var form = new ActionFormData();
                                                                 form.title(`${config['main'][0]}`);
                                                                 form.body(`§b${kannkin_information_system2[response][0]}\n§r1個/§b${kannkin_information_system2[response][1]}\n§e-----------\n§a換金取引数§r:§b${kannkin_log_system2[response]}`);
                                                                 form.button(`閉じる`);
                                                                 form.show(player).then(r => {
                                                                     if (r.canceled) return;
                                                                     let response = r.selection;
                                                                     
                                                                 })
                                                             })
                                                         break;
                                                         case 1:
                                                             var kounyuu_log = world.getDynamicProperty('kounyuu_log')
                                                             if(kounyuu_log==undefined){
                                                                 var kounyuu_log_system2=[]
                                                             }else{
                                                             var kounyuu_log_system2 = JSON.parse(kounyuu_log);
                                                             }
                                                             if(kounyuu_log_system2[0]==undefined){
                                                                 player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(購入)§r] §a換金取引ログがありません"}]}`)
                                                                 player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                                 return;
                                                             }
                                                             var kounyuu_information = world.getDynamicProperty('kounyuu_list')
                                                             if(kounyuu_information==undefined){
                                                                 var kounyuu_information_system2=[]
                                                             }else{
                                                             var kounyuu_information_system2 = JSON.parse(kounyuu_information);
                                                             }
                                                             if(kounyuu_information_system2[0]==undefined){
                                                                 player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(換金)§r] §a換金できるアイテムがありません"}]}`)
                                                                 player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                                 return;
                                                             }
                                                             var form = new ActionFormData();
                                                             form.title(`${config['main'][0]}`);
                                                             form.body(`§5換金ログ\n§e-----------\n§b[ログ]`);
                                                             for (let i = 0; i < kounyuu_information_system2.length; i++){
                                                                 form.button(`${kounyuu_information_system2[i][0]} 1個/§b${kounyuu_information_system2[i][1]}§r`,`textures/${kounyuu_information_system2[i][3]}`);
                                                             }
                                                             form.show(player).then(r => {
                                                                 if (r.canceled) return;
                                                                 let response = r.selection;
                                                                 var form = new ActionFormData();
                                                                 form.title(`${config['main'][0]}`);
                                                                 form.body(`§b${kounyuu_information_system2[response][0]}\n§r1個/§b${kounyuu_information_system2[response][1]}\n§e-----------\n§a購入取引数§r:§b${kounyuu_log_system2[response]}`);
                                                                 form.button(`閉じる`);
                                                                 form.show(player).then(r => {
                                                                     if (r.canceled) return;
                                                                     let response = r.selection;
                                                                     
                                                                 })
                                                             })
                                                         break;
                                                     }
                                                 })
                                             break;
                                         }
                                     })
                                 break;
                                 case 1:
                                     var form = new ActionFormData();
                                     form.title(`${config['main'][0]}`);
                                     form.body("データ編集する項目を選択");
                                     form.button("§5換金データ編集");
                                     form.button("§9購入データ編集");
                                     form.button("§4Quick相場情報の編集");
                                     form.show(player).then(r => {
                                         if (r.canceled) return;
                                         let response = r.selection;
                                         switch (response) {
                                             case 0:
                                                 var form = new ActionFormData();
                                                 form.title(`${config['main'][0]}`);
                                                 form.body("機能を選択");
                                                 form.button("§l追加");
                                                 form.button("§l編集");
                                                 form.button("§l削除");
                                                 form.show(player).then(r => {
                                                     if (r.canceled) return;
                                                     let response = r.selection;
                                                     switch (response) {
                                                         case 0:
                                                             var form = new ModalFormData();
                                                             form.textField("アイテム名", "ダイアモンド")
                                                             form.textField("アイテム換金金額", "0") 
                                                             form.textField("アイテムID", "diamond")
                                                             form.textField("アイコンパス(任意)", "items/diamond")
                                                             form.show(player).then(r => {
                                                                 if (r.canceled) return;
                                                                 var kannkin_information = world.getDynamicProperty('kannkin_information')
                                                                 if(kannkin_information==undefined){
                                                                     var kannkin_information_system2=[]
                                                                 }else{
                                                                 var kannkin_information_system2 = JSON.parse(kannkin_information);
                                                                 }
                                                                 kannkin_information_system2.push([r.formValues[0],r.formValues[1],r.formValues[2],r.formValues[3]])
                                                                 const kannkin_information_system3 = JSON.stringify(kannkin_information_system2);
                                                                 world.setDynamicProperty('kannkin_information',kannkin_information_system3)
                                                                 player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(換金)§r] §a追加しました"}]}`)
                                                                 player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                                 var kannkin_log = world.getDynamicProperty('kannkin_log')
                                                                 if(kannkin_log==undefined){
                                                                     var kannkin_log_system2=[]
                                                                 }else{
                                                                 var kannkin_log_system2 = JSON.parse(kannkin_log);
                                                                 }
                                                                 kannkin_log_system2.push(0)
                                                                 const kannkin_log_system3 = JSON.stringify(kannkin_log_system2);
                                                                 world.setDynamicProperty('kannkin_log',kannkin_log_system3)
                                                             })
                                                         break;
                                                         case 1:
                                                             var kannkin_information = world.getDynamicProperty('kannkin_information')
                                                                 if(kannkin_information==undefined){
                                                                     var kannkin_information_system2=[]
                                                                 }else{
                                                                 var kannkin_information_system2 = JSON.parse(kannkin_information);
                                                                 }
                                                                 if(kannkin_information_system2[0]==undefined){
                                                                     player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(換金)§r] §a編集できるアイテムがありません"}]}`)
                                                                     player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                                     return;
                                                                 }
                                                             var form = new ActionFormData();
                                                             form.title(`${config['main'][0]}`);
                                                             form.body("編集する換金アイテム/ブロックを選択");
                                                             for (let i = 0; i < kannkin_information_system2.length; i++){
                                                                 form.button(`${kannkin_information_system2[i][0]}:${kannkin_information_system2[i][1]}`);
                                                             }
                                                             form.show(player).then(r => {
                                                                 if (r.canceled) return;
                                                                 let response = r.selection;
                                                                 var form = new ModalFormData();
                                                                 form.textField("アイテム名", `${kannkin_information_system2[response][0]}`)
                                                                 form.textField("アイテム金額", `${kannkin_information_system2[response][1]}`) 
                                                                 form.textField("アイテムID", `${kannkin_information_system2[response][2]}`)
                                                                 form.textField("アイコンパス(任意)", `${kannkin_information_system2[response][3]}`) 
                                                                 form.show(player).then(r => {
                                                                     if (r.canceled) return;
                                                                     if(r.formValues[0]!=''){kannkin_information_system2[response][0]=r.formValues[0]}
                                                                     if(r.formValues[1]!=''){kannkin_information_system2[response][1]=r.formValues[1]}
                                                                     if(r.formValues[2]!=''){kannkin_information_system2[response][2]=r.formValues[2]}
                                                                     if(r.formValues[3]!=''){kannkin_information_system2[response][3]=r.formValues[3]}
                                                                     const kannkin_information_system3 = JSON.stringify(kannkin_information_system2);
                                                                     world.setDynamicProperty('kannkin_information',kannkin_information_system3)
                                                                     player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(換金)§r] §a編集しました"}]}`)
                                                                     player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                                 })
                                                             })
                                                         break;
                                                         case 2:
                                                             var kannkin_information = world.getDynamicProperty('kannkin_information')
                                                                 if(kannkin_information==undefined){
                                                                     var kannkin_information_system2=[]
                                                                 }else{
                                                                 var kannkin_information_system2 = JSON.parse(kannkin_information);
                                                                 }
                                                                 if(kannkin_information_system2[0]==undefined){
                                                                     player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(換金)§r] §a削除できるアイテムがありません"}]}`)
                                                                     player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                                     return;
                                                                 }
                                                             var form = new ActionFormData();
                                                             form.title(`${config['main'][0]}`);
                                                             form.body("削除する換金アイテム/ブロックを選択");
                                                             for (let i = 0; i < kannkin_information_system2.length; i++){
                                                                 form.button(`${kannkin_information_system2[i][0]}:${kannkin_information_system2[i][1]}`);
                                                             }
                                                             form.show(player).then(r => {
                                                                 if (r.canceled) return;
                                                                 let response = r.selection;
                                                                 kannkin_information_system2.splice( response, 1 );
                                                                 if(kannkin_information_system2==[]){
                                                                     kannkin_information_system2=undefined
                                                                 }
                                                                 const kannkin_information_system3 = JSON.stringify(kannkin_information_system2);
                                                                 world.setDynamicProperty('kannkin_information',kannkin_information_system3)
                                                                 player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(換金)§r] §a削除しました"}]}`)
                                                                 player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                                 var kannkin_log = world.getDynamicProperty('kannkin_log')
                                                                 if(kannkin_log==undefined){
                                                                     var kannkin_log_system2=[]
                                                                 }else{
                                                                 var kannkin_log_system2 = JSON.parse(kannkin_log);
                                                                 }
                                                                 kannkin_log_system2.splice( response, 1 );
                                                                 const kannkin_log_system3 = JSON.stringify(kannkin_log_system2);
                                                                 world.setDynamicProperty('kannkin_log',kannkin_log_system3)
                                                             })
                                                         break;
                                                     }
                                                 })          
                                             break;
                                             case 1:
                                                 var form = new ActionFormData();
                                                 form.title(`${config['main'][0]}`);
                                                 form.body("編集項目を選択...");
                                                 form.button("§l追加");
                                                 form.button("§l編集");
                                                 form.button("§l削除");
                                                 form.show(player).then(r => {
                                                     if (r.canceled) return;
                                                     let response = r.selection;
                                                     switch (response) {
                                                         case 0:
                                                             var form = new ModalFormData();
                                                             form.textField("アイテム名", "ダイアモンド")
                                                             form.textField("アイテム金額", "0") 
                                                             form.textField("アイテムID", "diamond")
                                                             form.textField("アイコンパス(任意)", "items/diamond")
                                                             form.show(player).then(r => {
                                                                 if (r.canceled) return;
                                                                 var kounyuu_list = world.getDynamicProperty('kounyuu_list')
                                                                 if(kounyuu_list==undefined){
                                                                     var kounyuu_list_system2=[]
                                                                 }else{
                                                                 var kounyuu_list_system2 = JSON.parse(kounyuu_list);
                                                                 }
                                                                 kounyuu_list_system2.push([r.formValues[0],r.formValues[1],r.formValues[2],r.formValues[3]])
                                                                 const kounyuu_list_system3 = JSON.stringify(kounyuu_list_system2);
                                                                 world.setDynamicProperty('kounyuu_list',kounyuu_list_system3)
                                                                 player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(購入)§r] §a追加しました"}]}`)
                                                                 player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                                 var kounyuu_log = world.getDynamicProperty('kounyuu_log')
                                                                 if(kounyuu_log==undefined){
                                                                     var kounyuu_log_system2=[]
                                                                 }else{
                                                                 var kounyuu_log_system2 = JSON.parse(kounyuu_log);
                                                                 }
                                                                 kounyuu_log_system2.push(0)
                                                                 const kounyuu_log_system3 = JSON.stringify(kounyuu_log_system2);
                                                                 world.setDynamicProperty('kounyuu_log',kounyuu_log_system3)
                                                             })
                                                         break;
                                                         case 1:
                                                             var kounyuu_list = world.getDynamicProperty('kounyuu_list')
                                                                 if(kounyuu_list==undefined){
                                                                     var kounyuu_list_system2=[]
                                                                 }else{
                                                                 var kounyuu_list_system2 = JSON.parse(kounyuu_list);
                                                                 }
                                                                 if(kounyuu_list_system2[0]==undefined){
                                                                     player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(購入)§r] §a編集できるアイテムがありません"}]}`)
                                                                     player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                                     return;
                                                                 }
                                                             var form = new ActionFormData();
                                                             form.title(`${config['main'][0]}`);
                                                             form.body("編集するアイテム/ブロックを選択");
                                                             for (let i = 0; i < kounyuu_list_system2.length; i++){
                                                                 form.button(`${kounyuu_list_system2[i][0]} 1個/§b${kounyuu_list_system2[i][1]}§r`,`textures/${kounyuu_list_system2[i][3]}`);
                                                             }
                                                             form.show(player).then(r => {
                                                                 if (r.canceled) return;
                                                                 let response = r.selection;
                                                                 var form = new ModalFormData();
                                                                 form.textField("アイテム名", `${kounyuu_list_system2[response][0]}`)
                                                                 form.textField("アイテム金額", `${kounyuu_list_system2[response][1]}`) 
                                                                 form.textField("アイテムID", `${kounyuu_list_system2[response][2]}`)
                                                                 form.textField("アイコンパス(任意)", `${kounyuu_list_system2[response][3]}`)
                                                                 form.show(player).then(r => {
                                                                     if (r.canceled) return;
                                                                     if(r.formValues[0]!=''){kounyuu_list_system2[response][0]=r.formValues[0]}
                                                                     if(r.formValues[1]!=''){kounyuu_list_system2[response][1]=r.formValues[1]}
                                                                     if(r.formValues[2]!=''){kounyuu_list_system2[response][2]=r.formValues[2]}
                                                                     if(r.formValues[3]!=''){kounyuu_list_system2[response][3]=r.formValues[3]}
                                                                     const kounyuu_list_system3 = JSON.stringify(kounyuu_list_system2);
                                                                     world.setDynamicProperty('kounyuu_list',kounyuu_list_system3)
                                                                     player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(購入)§r] §a編集しました"}]}`)
                                                                     player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                                 })
                                                             })
                                                         break;
                                                         case 2:
                                                             var kounyuu_list = world.getDynamicProperty('kounyuu_list')
                                                                 if(kounyuu_list==undefined){
                                                                     var kounyuu_list_system2=[]
                                                                 }else{
                                                                 var kounyuu_list_system2 = JSON.parse(kounyuu_list);
                                                                 }
                                                                 if(kounyuu_list_system2[0]==undefined){
                                                                     player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(購入)§r] §a削除できるアイテムがありません"}]}`)
                                                                     player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                                     return;
                                                                 }
                                                             var form = new ActionFormData();
                                                             form.title(`${config['main'][0]}`);
                                                             form.body("削除するアイテム/ブロックを選択");
                                                             for (let i = 0; i < kounyuu_list_system2.length; i++){
                                                                 form.button(`${kounyuu_list_system2[i][0]} 1個/§b${kounyuu_list_system2[i][1]}§r`,`textures/${kounyuu_list_system2[i][3]}`);
                                                             }
                                                             form.show(player).then(r => {
                                                                 if (r.canceled) return;
                                                                 let response = r.selection;
                                                                 kounyuu_list_system2.splice( response, 1 );
                                                                 if(kounyuu_list_system2==[]){
                                                                     kounyuu_list_system2=undefined
                                                                 }
                                                                 const kounyuu_list_system3 = JSON.stringify(kounyuu_list_system2);
                                                                 world.setDynamicProperty('kounyuu_list',kounyuu_list_system3)
                                                                 player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(購入)§r] §a削除しました"}]}`)
                                                                 player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                             })
                                                         break;
                                                     }
                                                 })        
                                             break;
                                             case 2:
                                                 var form = new ActionFormData();
                                                 form.title(`${config['main'][0]}`);
                                                 form.body("機能を選択");
                                                 form.button("§l追加");
                                                 form.button("§l編集");
                                                 form.button("§l削除");
                                                 form.show(player).then(r => {
                                                     if (r.canceled) return;
                                                     let response = r.selection;
                                                     switch (response) {
                                                         case 0:
                                                             var form = new ModalFormData();
                                                             form.textField("アイテム名", "ダイアモンドなど")
                                                             form.textField("アイテム金額", "0") 
                                                             form.show(player).then(r => {
                                                                 if (r.canceled) return;
                                                                 var quick_information = world.getDynamicProperty('quick_information')
                                                                 if(quick_information==undefined){
                                                                     var quick_information_system2=[]
                                                                 }else{
                                                                 var quick_information_system2 = JSON.parse(quick_information);
                                                                 }
                                                                 quick_information_system2.push([r.formValues[0],r.formValues[1]])
                                                                 const quick_information_system3 = JSON.stringify(quick_information_system2);
                                                                 world.setDynamicProperty('quick_information',quick_information_system3)
                                                                 player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(情報)§r] §a追加しました"}]}`)
                                                                 player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                             })
                                                         break;
                                                         case 1:
                                                             var quick_information = world.getDynamicProperty('quick_information')
                                                                 if(quick_information==undefined){
                                                                     var quick_information_system2=[]
                                                                 }else{
                                                                 var quick_information_system2 = JSON.parse(quick_information);
                                                                 }
                                                                 if(quick_information_system2[0]==undefined){
                                                                     player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(情報)§r] §a編集できるアイテムがありません"}]}`)
                                                                     player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                                     return;
                                                                 }
                                                             var form = new ActionFormData();
                                                             form.title(`${config['main'][0]}`);
                                                             form.body("編集する情報を選択");
                                                             for (let i = 0; i < quick_information_system2.length; i++){
                                                                 form.button(`${quick_information_system2[i][0]}:${quick_information_system2[i][1]}`);
                                                             }
                                                             form.show(player).then(r => {
                                                                 if (r.canceled) return;
                                                                 let response = r.selection;
                                                                 var form = new ModalFormData();
                                                                 form.textField("アイテム名", `${quick_information_system2[response][0]}`)
                                                                 form.textField("アイテム金額", `${quick_information_system2[response][1]}`) 
                                                                 form.show(player).then(r => {
                                                                     if (r.canceled) return;
                                                                     if(r.formValues[0]!=''){quick_information_system2[response][0]=r.formValues[0]}
                                                                     if(r.formValues[1]!=''){quick_information_system2[response][1]=r.formValues[1]}
                                                                     const quick_information_system3 = JSON.stringify(quick_information_system2);
                                                                     world.setDynamicProperty('quick_information',quick_information_system3)
                                                                     player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(情報)§r] §a編集しました"}]}`)
                                                                     player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                                 })
                                                             })
                                                         break;
                                                         case 2:
                                                             var quick_information = world.getDynamicProperty('quick_information')
                                                                 if(quick_information==undefined){
                                                                     var quick_information_system2=[]
                                                                 }else{
                                                                 var quick_information_system2 = JSON.parse(quick_information);
                                                                 }
                                                                 if(quick_information_system2[0]==undefined){
                                                                     player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(情報)§r] §a削除できるアイテムがありません"}]}`)
                                                                     player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                                     return;
                                                                 }
                                                             var form = new ActionFormData();
                                                             form.title(`${config['main'][0]}`);
                                                             form.body("削除する情報を選択");
                                                             for (let i = 0; i < quick_information_system2.length; i++){
                                                                 form.button(`${quick_information_system2[i][0]}:${quick_information_system2[i][1]}`);
                                                             }
                                                             form.show(player).then(r => {
                                                                 if (r.canceled) return;
                                                                 let response = r.selection;
                                                                 quick_information_system2.splice( response, 1 );
                                                                 if(quick_information_system2==[]){
                                                                     quick_information_system2=undefined
                                                                 }
                                                                 const quick_information_system3 = JSON.stringify(quick_information_system2);
                                                                 world.setDynamicProperty('quick_information',quick_information_system3)
                                                                 player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(情報)§r] §a削除しました"}]}`)
                                                                 player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                             })
                                                         break;
                                                     }
                                                 })  
                                             break;
                                         }
                                     })
                                 break;
                                 case 2:
                                     var form = new ActionFormData();
                                     form.title(`${config['main'][0]}`);
                                     form.body("権限削除する項目を選択");
                                     form.button("Quick出品アイテムの削除");
                                     form.button("§2仕事依頼の削除");
                                     form.button("§5ブラウザページの削除");
                                     form.button("§1広告ページの削除");
                                     form.show(player).then(r => {
                                         if (r.canceled) return;
                                         let response = r.selection;
                                         switch (response) {
                                             case 0:
                                            // shop_menu をグローバル変数として初期化
                                             var shop_menu = loadShopMenu();
                                             
                                             // 商品削除処理
                                             if (shop_menu[0].length == 0) {
                                                 player.sendMessage(`§r[§bQuick§r] §4削除できる商品が見つかりませんでした`);
                                                 player.playSound("random.toast", {
                                                     pitch: 0.4,
                                                     volume: 1.0
                                                 });
                                                 return;
                                             }
                                             player_Cash_Data[player.id].my_shop = [];
                                             var form = new ActionFormData();
                                             form.title(`${config['main'][0]}`);
                                             form.body("削除する商品を選択");
                                             for (let i = 0; i < shop_menu[0].length; i++) {
                                                 // プレイヤー自身の出品商品のみ表示
                                                 if (player.id == shop_menu[0][i][4]) {
                                                     form.button(`§l${shop_menu[0][i][0]}\n§r額:§b${shop_menu[0][i][2]}§rPAY  出品者:§2${shop_menu[0][i][1]}`);
                                                     player_Cash_Data[player.id].my_shop.push(shop_menu[0][i]);
                                                 }
                                             }
                                             if (player_Cash_Data[player.id].my_shop.length == 0) { // -1ではなく0に修正
                                                 player.sendMessage(`§r[§bQuick§r] §a削除できる商品が見つかりませんでした`);
                                                 player.playSound("random.toast", {
                                                     pitch: 0.4,
                                                     volume: 1.0
                                                 });
                                                 return;
                                             }
                                             form.show(player).then(r => {
                                                 if (r.canceled) {
                                                     return;
                                                 }
                                                 for (let i = 0; i < shop_menu[0].length; i++) {
                                                     if (shop_menu[0][i][5] === player_Cash_Data[player.id].my_shop[r.selection][5]) {
                                                         shop_menu[0].splice(i, 1);
                                                         break; // spliceしたらループを抜ける（インデックスが変わるため）
                                                     }
                                                 }
                                                 player.sendMessage(`§r[§bQuick§r] §a削除しました`);
                                                 player.playSound("random.toast", {
                                                     pitch: 1.7,
                                                     volume: 1.0
                                                 });
                                                 saveShopMenu(shop_menu); // データ保存
                                             }).catch(e => {
                                                 console.error(e, e.stack);
                                             }); 
                                             break;
                                             case 1:
                                                 if(quest[0]==undefined){
                                                     player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(設定)§r] §aデータがありません"}]}`) 
                                                     player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                   return
                                                 }
                                                 var form = new ActionFormData();
                                                 form.title(`${config['main'][0]}`);
                                                 form.body("shop_menuデータ");
                                                 for (let i = 0; i < quest.length; i++){
                                                     form.button(`§l${quest[i][0]}\n§r報酬額:§b${quest[i][2]}§rPAY  依頼者:§2${quest[i][3]}`);
                                                 }
                                                 form.show(player).then(r => {
                                                     if (r.canceled) return;
                                                     let response = r.selection;
                                                     player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(設定)§r] §a${quest[response]}を削除しました"}]}`) 
                                                     player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                     quest.splice( response, 1 );
                                                 }
                                                 )
                                             break;
                                             case 2:
                                                 var browser = world.getDynamicProperty('browser')
                                                         if(browser==undefined){
                                                             var browser_system2=[]
                                                         }else{
                                                         var browser_system2 = JSON.parse(browser);
                                                         }
                                                         if(browser_system2[0]==undefined){
                                                             player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r] §a削除できるページがありません"}]}`)
                                                             player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                             return;
                                                         }
                                                     var form = new ActionFormData();
                                                     form.title(`${config['main'][0]}`);
                                                     form.body("削除するページを選択");
                                                     for (let i = 0; i < browser_system2.length; i++){
                                                         form.button(`§l${browser_system2[i][2]}\n§r${browser_system2[i][3]}`);
                                                     }
                                                     form.show(player).then(r => {
                                                         if (r.canceled) return;
                                                         let response = r.selection;
                                                         browser_system2.splice( response , 1 );
                                                         const browser_system3 = JSON.stringify(browser_system2);
                                                         world.setDynamicProperty('browser',browser_system3)
                                                         player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r] §aページを削除しました"}]}`)
                                                         player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                     })
                                             break;
                                             case 3:
                                                 var browser = world.getDynamicProperty('performance')
                                                         if(browser==undefined){
                                                             var browser_system2=[]
                                                         }else{
                                                         var browser_system2 = JSON.parse(browser);
                                                         }
                                                         if(browser_system2[0]==undefined){
                                                             player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r] §a削除できる広告がありません"}]}`)
                                                             player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                             return;
                                                         }
                                                     var form = new ActionFormData();
                                                     form.title(`${config['main'][0]}`);
                                                     form.body("削除するページを選択");
                                                     for (let i = 0; i < browser_system2.length; i++){
                                                         form.button(`§l${browser_system2[i][2]}\n§r${browser_system2[i][3]}`);
                                                     }
                                                     form.show(player).then(r => {
                                                         if (r.canceled) return;
                                                         let response = r.selection;
                                                         browser_system2.splice( response , 1 );
                                                         const browser_system3 = JSON.stringify(browser_system2);
                                                         world.setDynamicProperty('performance',browser_system3)
                                                         player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r] §a広告を削除しました"}]}`)
                                                         player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                     })
                                             break;
                                         }
                                     })
                                 break;
                                 case 3:
                                     var form = new ActionFormData();
                                     form.title(`${config['main'][0]}`);
                                     form.body("トラブルシューティング機能を選択");
                                     form.button("§2キャッシュデーターの削除");
                                     form.button("§1プレイヤーキルcountリセット");
                                     form.show(player).then(r => {
                                         if (r.canceled) return;
                                         let response = r.selection;
                                         switch (response) {
                                             case 0:
                                                 var players = world.getAllPlayers()
                                                 for (let i = 0; i < players.length; i++){
                                                    
                                                 }
                                               //キャッシュデータの削除
                                                 cashdataB(player);//HARUPhone関連
                                                 cashdataC(player);//HARUPhone関連
                                                 player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(設定)§r] §aキャッシュデータを削除しました"}]}`) 
                                                 player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)    
                                             break;
                                             case 1:
                                                 var players = world.getAllPlayers()
                                                 for (let i = 0; i < players.length; i++){
                                                     players[i].setDynamicProperty('skeletoncount',0)
                                                     players[i].setDynamicProperty('zombiecount',0)
                                                     players[i].setDynamicProperty('phantomcount',0)
                                                     players[i].setDynamicProperty('wardencount',0)
                                                     players[i].setDynamicProperty('creepercount',0)
                                                     players[i].setDynamicProperty('spidercount',0)
                                                     players[i].setDynamicProperty('endermancount',0)
                                                 }
                                                 player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(設定)§r] §aプレイヤーキルcountをリセットしました"}]}`) 
                                                 player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)    
                                             break;
                                         }
                                     })
                                 break;         
                                 case 4:
                                     var form = new ActionFormData();
                                     form.title(`${config['main'][0]}`);
                                     form.body("カスタマイズする機能を選択");
                                     form.button("§2ブラウザ関連");
                                     form.show(player).then(r => {
                                         if (r.canceled) return;
                                         let response = r.selection;
                                         switch (response) {
                                             case 0:
                                                 var form = new ActionFormData();
                                                 form.title(`${config['main'][0]}`);
                                                 form.body("設定を選択...");
                                                 form.button("§rページ投稿金額設定");
                                                 form.button("§r広告化金額設定");
                                                 form.show(player).then(r => {
                                                     if (r.canceled) return;
                                                     let response = r.selection;
                                                     switch (response) {
                                                         case 0:
                                                             var form = new ModalFormData();
                                                             form.textField("ページ投稿金額(半角数字)", `${world.getDynamicProperty('browser_newpage_money')}`)
                                                             form.show(player).then(r => {
                                                                 if (r.canceled) return;
                                                                 world.setDynamicProperty('browser_newpage_money',r.formValues[0])
                                                                 player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r] §aページ投稿金額を設定しました"}]}`)
                                                                 player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                             })
                                                         break;
                                                         case 1:
                                                             var form = new ModalFormData();
                                                             form.textField("広告化金額(半角数字)", `${world.getDynamicProperty('browser_performance_money')}`)
                                                             form.show(player).then(r => {
                                                                 if (r.canceled) return;
                                                                 world.setDynamicProperty('browser_performance_money',r.formValues[0])
                                                                 player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r] §a広告化金額を設定しました"}]}`)
                                                                 player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                             })
                                                         break;
                                                     }
                                                 }) 
                                             break;
                                         }
                                     })
                                 break;
                                 case 5:
                                     var form = new ActionFormData();
                                     form.title(`${config['main'][0]}`);
                                     form.body("設定する項目を選択");
                                     form.button("§d初期金額の再設定");
                                     form.button("§1新規プレイヤーにスマホ/マネー付与");
                                     form.button("§3自動付与システム");
                                     form.button("§4キルカウントシステム");
                                     form.button("§0永久保存\n§5有効化§r/§1無効化");
                                     form.show(player).then(r => {
                                         if (r.canceled) return;
                                         let response = r.selection;
                                         switch (response) {
                                             case 0:
                                                 world.setDynamicProperty('op_fast', undefined)
                                                 player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(設定)§r] §a初期金額設定をリセットしました.§5スマホを開くと再設定できます."}]}`)
                                                 player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                             break;
                                             case 1:
                                                 var players = world.getAllPlayers()
                                                 var form = new ActionFormData();
                                                 form.title(`${config['main'][0]}`);
                                                 form.body("新規プレイヤーにスマホ/Money付与");
                                                 for (let i = 0; i < players.length; i++){
                                                  form.button(`${players[i].name}`)   
                                                 }
                                                 form.show(player).then(r => {
                                                     let response = r.selection;
                                                     if (r.canceled) {
                                                         return;
                                                     }
                                                     var partner1 = players[response];
                                                     if(partner1.hasTag('HARUPAY_Member')){
                                                         player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(設定)§r] §4このPlayerは付与済みです"}]}`) 
                                                         player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                         return;
                                                     }
                                                     partner1.runCommand("give @s additem:haruphone1");
                                                     partner1.runCommand(`scoreboard players add @s money ${world.getDynamicProperty('start_money')}`);
                                                     partner1.runCommand(`scoreboard players add @s account 0`);
                                                     partner1.runCommand("tag @s add HARUPAY_Member")
                                                     player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(設定)§r] §eこのPlayerに付与しました"}]}`)
                                                     player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                               })
                                             break;
                                             case 2:
                                                 var form = new ActionFormData();
                                                 form.title(`${config['main'][0]}`);
                                                 form.body("設定を選択...");
                                                 form.button("§5有効化");
                                                 form.button("§1無効化");
                                                 form.show(player).then(r => {
                                                     if (r.canceled) return;
                                                     let response = r.selection;
                                                     switch (response) {
                                                         case 0:
                                                             world.setDynamicProperty('money_start_system2',0)
                                                             player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(設定)§r] §5有効化§aにしました"}]}`)
                                                             player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                         break;
                                                         case 1:
                                                             world.setDynamicProperty('money_start_system2',1)
                                                             player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(設定)§r] §9無効化§aにしました"}]}`)
                                                             player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                         break;
                                                     }
                                                 })
                                             break;
                                             case 3:
                                                var form = new ActionFormData();
                                                 form.title(`${config['main'][0]}`);
                                                 form.body("設定を選択...");
                                                 form.button("§5有効化§0/§1無効化");
                                                 form.button("§sキルカウント/ポイント編集");
                                                 form.show(player).then(r => {
                                                     if (r.canceled) return;
                                                     let response = r.selection;
                                                     switch (response) {
                                                         case 0:
                                                            var form = new ActionFormData();
                                                            form.title(`${config['main'][0]}`);
                                                            form.body("設定を選択...");
                                                            form.button("§5有効化");
                                                            form.button("§1無効化");
                                                            form.show(player).then(r => {
                                                                if (r.canceled) return;
                                                                let response = r.selection;
                                                                switch (response) {
                                                                    case 0:
                                                                        world.setDynamicProperty('killPointSystem',true) 
                                                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(設定)§r] §5有効化§aにしました"}]}`)
                                                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                                    break;
                                                                    case 1:
                                                                        world.setDynamicProperty('killPointSystem',false) 
                                                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(設定)§r] §9無効化§aにしました"}]}`)
                                                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                                    break;
                                                                }
                                                            })
                                                         break;
                                                         case 1:
                                                            var form = new ActionFormData();
                                                            form.title(`${config['main'][0]}`);
                                                            form.body("編集するモブを選択");
                                                            form.button("§2ゾンビ");
                                                            form.button("§0スケルトン");
                                                            form.button("§4蜘蛛");
                                                            form.button("§2クリーパー");
                                                            form.button("§0エンダーマン");
                                                            form.button("§sウォーデン");
                                                            form.button("§5ファントム");
                                                            form.show(player).then(r => {
                                                                if (r.canceled) return;
                                                                let response = r.selection;
                                                                const kill_id = ['killcount_zombie','killcount_skeleton','killcount_spider','killcount_creeper','killcount_enderman','killcount_warden','killcount_phantom']
                                                                const kill_id_2 = ['killpoint_zombie','killpoint_skeleton','killpoint_spider','killpoint_creeper','killpoint_enderman','killpoint_warden','killpoint_phantom']
                                                                        var form = new ModalFormData();
                                                                        form.textField("キルカウント", `${world.getDynamicProperty(kill_id[response])}`)
                                                                        form.textField("キルポイント", `${world.getDynamicProperty(kill_id_2[response])}`)
                                                                        form.show(player).then(r => {
                                                                            if (r.canceled) return;
                                                                            if(isNaN(r.formValues[0])||isNaN(r.formValues[1])){
                                                                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(システム)§r] §4半角数字で入力してください"}]}`)
                                                                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                                                return;
                                                                            }
                                                                            if (r.formValues[0]==''||r.formValues[1]==''){
                                                                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(システム)§r] §4入力してください"}]}`)
                                                                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                                                return;
                                                                            }
                                                                            if (r.formValues[0]<0||r.formValues[1]<0){
                                                                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(システム)§r] §40以下は設定できません"}]}`)
                                                                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                                                return;
                                                                            }
                                                                            world.setDynamicProperty(`${kill_id[response]}`,Number(r.formValues[0]))
                                                                            world.setDynamicProperty(`${kill_id_2[response]}`,Number(r.formValues[1]))
                                                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(システム)§r] §a設定しました"}]}`)
                                                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                                        })
                                                                    })
                                                     }
                                                 })
                                             break;
                                             case 4:
                                                var form = new ActionFormData();
                                                form.title(`${config['main'][0]}`);
                                                form.body("設定を選択...");
                                                form.button(`§0Quick\n§1現在§5>>>§s${world.getDynamicProperty('Quick_DataSAVE')}`);
                                                form.show(player).then(r => {
                                                    if (r.canceled) return;
                                                    let response = r.selection;
                                                    switch (response) {
                                                        case 0:
                                                            var form = new ActionFormData();
                                                            form.title(`${config['main'][0]}`);
                                                            form.body("保存システム");
                                                            form.button("§5有効化");
                                                            form.button("§1無効化");
                                                            form.show(player).then(r => {
                                                                if (r.canceled) return;
                                                                let response = r.selection;
                                                                switch (response) {
                                                                    case 0:
                                                                        world.setDynamicProperty('Quick_DataSAVE',true) 
                                                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(設定)§r] §5有効化§aにしました"}]}`)
                                                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                                    break;
                                                                    case 1:
                                                                        world.setDynamicProperty('Quick_DataSAVE',false) 
                                                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(設定)§r] §9無効化§aにしました"}]}`)
                                                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                                    break;
                                                                }
                                                            })
                                                        break;
                                                    }
                                                })
                                             break;
                                         }
                                     })
                                 break;   
                                 case 6:
                         //HARUPAY画面
                         var form = new ActionFormData();
                         form.title(`${config['main'][0]}`);
                         form.body("管理者版HARU PAY");
                         form.button("§2§l残高の確認");
                         form.button("§6§l送る");
                         form.button("§e§lチャージ");
                         form.show(player).then(r => {
                             if (r.canceled) return;
                             let response = r.selection;
                             switch (response) {
                                 case 0:
                                     //HARUPAYの残高の確認
                                     player.runCommand(`tellraw @s {"rawtext":[{"text":"§a管理者§fのHARUPAY所持金:§l§b${world.getDynamicProperty('harupay_op_money')}"}]}`)
                                     player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                 break;
                                 case 1:
                                     //サーバーが混みあった際の不具合防止
                                     if(selection_HARUPAYSend_import==1){
                                         player.runCommand(`tellraw @s {"rawtext":[{"text":"§eただいまサーバーが混みあっております.しばらくしてからもう一度お試しください"}]}`) 
                                         return;
                                     }
                                         var players = world.getAllPlayers()
                                         selection_HARUPAYSend_import = 1;
                                     //サーバー使用中の設定   
                                     //全プレイヤー取得
                                     //HARIPAY送信画面
                                     form = new ActionFormData();
                                     form.body("送り先のプレイヤーを選択");
                                     for (let i = 0; i < players.length; i++){
                                         form.button(`${players[i].name}`);
                                     }
                                     form.show(player).then(r => {
                                         if (r.canceled) {
                                             selection_HARUPAYSend_import = 0;
                                             return;
                                         };
                                         let response = r.selection;
                                         //playerの残高の取得
                                         const score = Number(world.getDynamicProperty('harupay_op_money'))
                                         //送信先プレイヤーの設定
                                         let partner = players[response].name
                                         //送金額設定画面
                                         var form = new ModalFormData();
                                         form.textField("送金額(半角数字)", "0")
                                         form.show(player).then(r => {
                                             if (r.canceled) {
                                                 selection_HARUPAYSend_import = 0;
                                                 return;
                                             };
                                             if(isNaN(r.formValues[0])){
                                                 player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(管理者版HARUPAY)§r] §4半角数字で入力してください"}]}`)
                                                 player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                 selection_HARUPAYSend_import = 0;
                                                 return;
                                             }
                                             if (r.formValues[0]>100000000){
                                                 player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(管理者版HARUPAY)§r] §4設定した金額は上限をオーバーしています.1億以下で設定してください"}]}`)
                                                 player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                 selection_HARUPAYSend_import = 0;
                                                 return;
                                             }
                                             if (r.formValues[0]<0){
                                                 player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(管理者版HARUPAY)§r] §40以下は設定できません"}]}`)
                                                 player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                 selection_HARUPAYSend_import = 0;
                                                 return;
                                             }
                                             var selection_score_harupay = 0;
                                             if(r.formValues[0]=='') {selection_score_harupay=0}else{
                                                 selection_score_harupay=r.formValues[0]
                                             }
                                             //残高不足時メッセージ
                                             player.runCommand(`tellraw @a[name="${player.name}", scores={money=..${selection_score_harupay-1}}] {"rawtext":[{"text":"§r[§a通知§7(管理者版HARUPAY)§r] §eHARUPAY残高が不足しています"}]}`)
                                             player.runCommand(`playsound random.toast @a[name="${player.name}", scores={money=..${selection_score_harupay-1}}] ~ ~ ~ 1.0 0.4 0.7`)
                                             //残高が設定金額以上の場合のみ実行
                                             if(score >= selection_score_harupay){
                                                 player.runCommand(`scoreboard players add @a[name="${partner}"] money ${selection_score_harupay}`)  
                                                 player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(管理者版HARUPAY)§r] §b${partner}へ送信されました"}]}`) 
                                                 player.runCommand(`tellraw @a[name="${partner}"] {"rawtext":[{"text":"§r[§a通知§7(管理者版HARUPAY)§r] §b管理者マネーから${selection_score_harupay}PAY受け取りました"}]}`) 
                                                 player.runCommand(`playsound random.toast @a[name="${partner}"] ~ ~ ~ 1.0 1.7 1.0`)  
                                                 player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 1.0`)  
                                                 world.setDynamicProperty('harupay_op_money',Number(world.getDynamicProperty('harupay_op_money'))-Number(selection_score_harupay))
                                                 const timer = new Date();
                                                 harupay_logs[harupay_logs.length]=`[${timer.getHours()}:${timer.getMinutes()}]管理者が${partner}へ${selection_score_harupay}PAY送信`
                                              }
                                              selection_HARUPAYSend_import = 0;
                                         })
                                     })
                                 break;
                                 case 2:
                                     //HAURPAYチャージ画面
                                     var form = new ModalFormData();
                                     form.textField("チャージ金額(半角数字)", "0") 
                                     form.show(player).then(r => {
                                         if (r.canceled) {
                                             return;
                                         };
                                         if(isNaN(r.formValues[0])){
                                             player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(管理者版HARUPAY)§r] §4半角数字で入力してください"}]}`)
                                             player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                             return;
                                         }
                                         if (r.formValues[0]<0){
                                             player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(管理者版HARUPAY)§r] §40以下は設定できません"}]}`)
                                             player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                             return;
                                         }
                                         var selection_score_charge = 0
                                         if(r.formValues[0]=='') {selection_score_charge=0}else{
                                             selection_score_charge=r.formValues[0]
                                          }
                                         player.runCommand(`tellraw @s[hasitem={item=additem:hyoutaroucoin,quantity=..${(selection_score_charge / 100)-1}}] {"rawtext":[{"text":"§r[§a通知§7(管理者版HARUPAY)§r] §4コインが不足しています"}]}`)
                                         player.runCommand(`tag @s[hasitem={item=additem:hyoutaroucoin,quantity=${selection_score_charge / 100}..}] add harupaymoneysystem2`)
                                         if(player.hasTag('harupaymoneysystem2')){
                                             world.setDynamicProperty('harupay_op_money',Number(world.getDynamicProperty('harupay_op_money'))+Number(selection_score_charge))
                                             player.runCommand(`tellraw @s[hasitem={item=additem:hyoutaroucoin,quantity=${selection_score_charge / 100}..}] {"rawtext":[{"text":"§r[§a通知§7(管理者版HARUPAY)§r] §3${selection_score_charge}PAYチャージしました"}]}`)
                                         }
                                         player.runCommand(`playsound random.toast @s[hasitem={item=additem:hyoutaroucoin,quantity=${selection_score_charge / 100}..}] ~ ~ ~ 1.0 1.7 1.0`)
                                         player.runCommand(`playsound random.toast @s[hasitem={item=additem:hyoutaroucoin,quantity=..${(selection_score_charge / 100)-1}}] ~ ~ ~ 1.0 0.4 0.7`)
                                         player.runCommand(`clear @s[hasitem={item=additem:hyoutaroucoin,quantity=${selection_score_charge / 100}..}] additem:hyoutaroucoin 0 ${selection_score_charge / 100}`)
                                         player.runCommand(`tag @s remove harupaymoneysystem2`)
                                     })
                                 break;
                                 default:
                             }
                         })
                                 break;
                                 default:
                             }
                         }).catch(e => {
                             console.error(e, e.stack);
                         });
                    break;
                    default:
                }
            })
        }
    }
  })
}
