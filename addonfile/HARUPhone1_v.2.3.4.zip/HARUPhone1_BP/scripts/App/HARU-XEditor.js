import { world, system } from "@minecraft/server";
import { ActionFormData,MessageFormData,ModalFormData } from "@minecraft/server-ui";
import { config } from "../config"
import { HARU_XEditor_LiteFrame_NewApp } from "../HARU-XEditor/LiteFrame/NewApp"
import { LiteFrame_editor } from "../HARU-XEditor/LiteFrame/editor/LiteFrame_editor"

var  player_Cash_Data = {}
export function HARU_XEditor(eventData){
    system.run(() => {
        const player = eventData.source;
        if(!player.hasTag('HARUPhoneOP')) {
            player.sendMessage(`§r[§bHARU-XEditor§r] §4管理者のみ利用できます`)
            player.playSound("random.toast", {
                pitch: 0.6, 
                volume: 1.0
            });  
            return;
        }

        //MyAPP取得
        var MY_AppData = player.getDynamicProperty(`MY_AppData`)
        if(MY_AppData==undefined){
            var MY_AppData = []
        }else{
         var MY_AppData = JSON.parse(MY_AppData);
        }

        //時刻を取得
        const now = new Date();
        const japanTime = new Date(now.getTime() + 9 * 60 * 60 * 1000);
        const hours = String(japanTime.getUTCHours()).padStart(2, "0");
        const minutes = String(japanTime.getUTCMinutes()).padStart(2, "0");
        var time = `${hours}:${minutes}`
        var form = new ActionFormData();
        form.title(`${config['main'][0]}`);
        form.body(`§l§b${time}\n§r§5>>>§sHARU-XEditor§5<<<`);
        form.button(`§5新規作成`);
        for (let i = 0; i < MY_AppData.length; i++){
            form.button(`§1${MY_AppData[i][0]}`);
        }
        form.show(player).then(r => {
            if (r.canceled) return;
            if(r.selection == 0){
                HARU_XEditor_NewApp(eventData,time)
                return;
            }
            const target = MY_AppData[r.selection - 1][1];
            const LiteFrame = ["LiteFrameA", "LiteFrameB", "LiteFrameC", "LiteFrameD"];
            
            if (LiteFrame.includes(target)) {
                LiteFrame_editor(eventData, MY_AppData[r.selection - 1]);
            }
        })
    })
}

//新規作成
function HARU_XEditor_NewApp(eventData,time){
    const player = eventData.source;
    
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body(`§l§b${time}\n§r§5>>>§rどの§bフレームワーク§rを利用して、§e開発§rを行いますか？`);
    form.button(`§1LiteFrame`);
    form.button(`§5Vortex\n§8利用不可`);
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                HARU_XEditor_LiteFrame_NewApp(eventData)
            break;
            case 1:
            break;
        }
    })
}
